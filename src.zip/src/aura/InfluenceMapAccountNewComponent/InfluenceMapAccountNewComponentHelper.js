({
    orgChart: {},
    
    /* JSON Static Data is loaded globally in order to be used in multiple helper methods */
    dataSource: [{
            'name': 'Jack',
            'email': 'Jack@gmail.com',
            'oppRole': 'Champion',
            'organization': 'I.T',
            'id': '1'
        },
        {
            'name': 'Jill',
            'email': 'Jill@gmail.com',
            'oppRole': 'Mobilizers',
            'organization': 'I.T',
            'id': '2'
        },
        {
            'name': 'kathe',
            'email': 'kathe@gmail.com',
            'oppRole': 'Neutral',
            'organization': 'I.T',
            'id': '3'
        },
        {
            'name': 'decaprio',
            'email': 'decaprio@gmail.com',
            'oppRole': 'Blocker',
            'organization': 'I.T',
            'id': '4'
        },
        {
            'name': 'jack',
            'email': 'jack@gmail.com',
            'oppRole': 'Mobilizer instead Mobilizers',
            'organization': 'I.T',
            'id': '5'
        },
        {
            'name': 'rose',
            'email': 'rose@gmail.com',
            'oppRole': 'Neutral',
            'organization': 'I.T',
            'id': '6'
        },
        {
            'name': 'James',
            'email': 'James@gmail.com',
            'oppRole': 'Mobilizers',
            'organization': 'I.T',
            'id': '7'
        }, {
            'name': 'Cameron',
            'email': 'Cameron@gmail.com',
            'oppRole': 'Champion',
            'organization': 'I.T',
            'id': '8'
        }
    ],
     /* calling openSuggestionsHelper Method(passing JSON DATA as a new Argument) as this 
    	Method is being called from rerenderer where DataSource is not Available. */
    openSuggestions: function(component, event, helper) {
         helper.openSuggestionsHelper(component, event, helper, helper.dataSource)
    },
    /*This will create the Auto-Complete functionality on typing on the input-field. */
    openSuggestionsHelper: function(component, event, helper, dataSource) {
        var autoComplete = event.target;
        var autoComplete_Result = event.target.nextSibling;

        helper.popUpClearAndHide(component, event, helper, autoComplete_Result);

        var a = new RegExp("^" + autoComplete.value, "i");
        for (var x = 0, b = document.createDocumentFragment(), c = false; x < dataSource.length; x++) {
            if (a.test(dataSource[x].name)) {
                c = true;
                var d = document.createElement("p");
                d.innerText = dataSource[x].name;
                d.setAttribute("data-id", dataSource[x].id);
                b.appendChild(d);
            }
        }
        if (c == true) {
            autoComplete_Result.innerHTML = "";
            autoComplete_Result.style.display = "block";
            autoComplete_Result.appendChild(b);
            return;
        }
    },
    /* Hide the pop-up when user clears the input from the input-field. */
    popUpClearAndHide: function(component, event, helper, autoComplete_Result) {
        autoComplete_Result.innerHTML = "";
        autoComplete_Result.style.display = "none";
    },
    /* calling selectItemHelper Method(passing JSON DATA as a new Argument) as this 
       Method is being called from rerenderer where DataSource is not Available. */
    selectItem: function(component, event, helper) {
         helper.selectItemHelper(component, event, helper, helper.dataSource);
    },
    /*Selects contact from the Suggested Contacts */
    selectItemHelper: function(component, event, helper, dataSource) {
		
        //get all the required fields
        var input = event.target.parentElement.previousSibling;
        var inputOrg = event.target.parentElement.nextSibling;
        var inputEmail = event.target.parentElement.nextSibling.nextSibling;
        var inputRole = event.target.parentElement.nextSibling.nextSibling.nextSibling;
        //loop through the dataSource.
        for (var i = 0; i < dataSource.length; i++) {
           // identify the correct contact , set the values in the fields.
            if (dataSource[i].id == event.target.dataset.id) {
                input.value = dataSource[i].name
                inputEmail.value = dataSource[i].email
                inputOrg.value = dataSource[i].organization
                inputRole.value = dataSource[i].oppRole
            }
        }
       // clearing and hiding the Suggested Contacts List upon selection.
        event.target.parentElement.innerHtml = "";
        event.target.parentElement.style.display = "none";
    },
   /* This method will bind the actions on adding new Nodes */
    bindActions: function(component, helper) {
        window.setTimeout(function() {
          //when users type something on the inputField this action will bind to the event.
            $('.inputSearch').bind("keydown", function() {
                helper.openSuggestions(component, event, helper)
            });
          //when users select contact from the suggested Contact-List this action will bind to the event.
            $('.suggestion').bind("click", function() {
                helper.selectItem(component, event, helper)
            });
        }, 1000);
    },
 })