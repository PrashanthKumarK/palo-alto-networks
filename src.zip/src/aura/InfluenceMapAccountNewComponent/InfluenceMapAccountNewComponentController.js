({
    doInit: function(component, event, helper) {},
    /*Indicates that the initial rendering of the root application has completed. */
    doneRendering: function(component, event, helper) {
        if (!component.get("v.isDoneRendering")) {
            component.set("v.isDoneRendering", true);
            var dataSource = {
                'name': 'Jay',
                'email': 'jay@gmail.com',
                'oppRole': 'MD',
                'organization': 'I.T',
                'children': [{
                        'name': 'Jack',
                        'email': 'Jack@gmail.com',
                        'oppRole': 'Champion',
                        'organization': 'I.T',
                        'children': [{
                                'name': 'cris',
                                'email': 'cris@gmail.com',
                                'oppRole': 'Champion',
                                'organization': 'I.T'
                            }

                        ]
                    },
                    {
                        'name': 'James',
                        'email': 'James@gmail.com',
                        'oppRole': 'Mobilizers',
                        'organization': 'I.T',
                        'children': [{
                                'name': 'Cameron',
                                'email': 'Cameron@gmail.com',
                                'oppRole': 'Champion',
                                'organization': 'I.T'
                            }

                        ]
                    },
                    {
                        'name': 'June',
                        'email': 'June@gmail.com',
                        'oppRole': 'Neutral',
                        'organization': 'I.T',
                        'children': [{
                                'name': 'David',
                                'email': 'david@gmail.com',
                                'oppRole': 'Champion',
                                'organization': 'I.T'
                            },
                            {
                                'name': 'Denny',
                                'email': 'denny@gmail.com',
                                'oppRole': 'Mobilizers',
                                'organization': 'I.T'
                            }

                        ]
                    },

                ]
            };
            /*Setting 3 seconds delayed time to let the static resources load completely. */
            setTimeout(function() {
                var element = $(component.find('chart-Container').getElement());
                helper.orgChart = element.orgchart({
                    'data': dataSource,
                    'createNode': function($node, data) {
                        //setting a unique id to every node.     
                        $node[0].id = (new Date().getTime()) * 1000 + Math.floor(Math.random() * 1001);
                
                		//injecting the required HTML.
                        $node[0].innerHTML =
                            '<div id="addNode" class="addNode" title="Click add contacts below"> + </div>' +
                            '<div aura:id="node">' +
                            '<input type="text" aura:id="input" class="inputSearch" value="' + data.name + '"  autocomplete="off" placeholder="Search Contact" ></input>' +
                            '<div class="suggestion" aura:id="suggestion" > </div>' +
                            '<input type="text" class="input-Text organization" value="' + (data.organization ? data.organization : '') + '" aura:id="inputRole" ></input>' +
                            '<input type="text" class="input-Text email" value="' + (data.email ? data.email : '') + '" aura:id="inputEmail" ></input>' +

                            '<select class="select" value="' + (data.oppRole) + '" >' +
                            '<option value="Select">Select</option>' +
                            '<option value="Champion">Champion</option>' +
                            '<option value="Mobilizers" >Mobilizers</option>' +
                            '<option value="Neutral">Neutral</option>' +
                            '<option value="Blocker">Blocker</option>' +
                            '<option value="Mobilizer instead Mobilizers">Mobilizer instead Mobilizers</option>' +
                            '</select>' +

                            '</div>' +
                            '<div id="deleteNode" class="deleteNode"  title="Click to remove"  > x  </div>';
                    }
                })
            }, 3000);
        }
    },
     /*This function will catch the event on the basis of button click- Add/Delete and execute the Action. */
    action: function(component, event, helper) {
        if (event.target.id == 'addNode') {
            var oc = helper.orgChart;
            $node = $(event.target.parentElement);
            var data = {
                'children': [{
                    'name': '',
                    'relationship': '110'
                }]
            }
            //Check if the focussed node already has a child or not.
            var hasChild = $node.parent().attr('colspan') > 0 ? true : false;
            //if not, Add a chid Node else add a sibling to the already present child Node(s).
            if (!hasChild) {
                oc.addChildren($node, data);
             } else {
                console.log($node.closest('tr').siblings('.nodes').find('.node:first'));
                oc.addSiblings($node.closest('tr').siblings('.nodes').find('.node:first'), {
                    'siblings': [{
                        'name': '',
                        'relationship': '110',
                        'Id': '12333'
                    }]
                })
            }
            /* Calling helper bindActions method to load the data once again for the newly added nodes. */
            helper.bindActions(component, helper);
        } else if (event.target.id == 'deleteNode') {
            
             if(window.confirm('Are you sure ?') ){
                var oc = helper.orgChart;
                var $node = $(event.target.parentElement);
                
                //if user is trying to delete the top level node. 
                if ($node[0] === $('.orgchart').find('.node:first')[0]) {
                    if (!window.confirm('you are going to delete the whole chart!!!')) {
                        return;
                    }
                }
                oc.removeNodes($node);
                $(event.target.parentElement).val('').data('node', '')
             }
        }
     }
})