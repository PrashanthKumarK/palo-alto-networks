({
	closeContactModal : function(component, event, helper){
        //fire cancelModal event, 
        var cancelEvent = component.getEvent("cancelModalEvent");
        cancelEvent.fire();
    },
    saveContact : function(component, event, helper){
        component.set("v.errorMessage","");
        var isValidData = helper.validData(component)
        //replace true with isValidData when this function works perfectly
        if(isValidData){
            helper.fireSaveEvent(component,event);
        }
        else{
            $(".error.uiMessage").css("display","block");            
        }

    },
    selectedContactEvent : function(component, event, helper){
        component.set("v.nodeData.objContact", event.getParam("contact"));
        var contact = component.get("v.nodeData.objContact");
        component.set("v.nodeData.objInfluenceMap.Contact__c", contact.Id);
        //console.log("modalComponent-- selectedContactEvent fn, nodeData : ", component.get("v.nodeData"));
    }
})