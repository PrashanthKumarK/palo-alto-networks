({
	validData : function(component) {
		var contactName = component.get("v.nodeData.objContact.Name");
        var contactBuyingRole = component.get("v.nodeData.objInfluenceMap.Buying_Role__c");
        var contactStatus = component.get("v.nodeData.objInfluenceMap.Status__c");
        var contactFocus = component.get("v.nodeData.objInfluenceMap.Focus__c");
        var contactLevel = component.get("v.nodeData.objInfluenceMap.Level_of_Contact__c");
        
        if(!contactName || !contactBuyingRole || !contactStatus || !contactFocus || !contactLevel){
            //console.log("some fields are incomplete");
            
            if(!contactName)
                component.set("v.errorMessage","Contact Name can't be empty");
            else if(!contactBuyingRole)
                component.set("v.errorMessage","Buying Role can't be empty");
            else if(!contactStatus)
                component.set("v.errorMessage","Status can't be empty");
            else if(!contactFocus)
                component.set("v.errorMessage","Focus can't be empty");
            else if(!contactLevel)
                component.set("v.errorMessage","Contact Level can't be empty");
            
            return false;
        }
        return true;
	},
    fireSaveEvent : function(component,event){
        if(component.get("v.eventName") == "Add"){
            var nodeData = component.get("v.nodeData");
            //console.log("fireSaveEvent-- nodeData : ", nodeData);
            var recordId = nodeData.objInfluenceMap.Id;
            var parentId = "";
            if(nodeData.objInfluenceMap.Parent_Influencer__c)
                parentId = nodeData.objInfluenceMap.Parent_Influencer__c;
            //if first node is being added, then recordid & parentId both values will be blank
            if(!parentId && !recordId){
                //Id length more than 18, parentId will remain blank
                component.set("v.nodeData.objInfluenceMap.Id", "123456789123456789" + Math.floor(Math.random()*1000));
                component.set("v.nodeData.objInfluenceMap.Parent_Influencer__c", "");
            }
            else if(parentId && !recordId){
                component.set("v.nodeData.objInfluenceMap.Id", parentId + Math.floor(Math.random()*1000));
            }
        }
        //update values in the event handler
        var shareModalData = component.getEvent("shareModalData");
        shareModalData.setParams({
            "recordId" : component.get("v.nodeData.objInfluenceMap.Id"),
            "parentId" : component.get("v.nodeData.objInfluenceMap.Parent_Influencer__c"),
            "nodeData" : component.get("v.nodeData"),
            "eventName" : component.get("v.eventName")
        });
        shareModalData.fire();
    }
})