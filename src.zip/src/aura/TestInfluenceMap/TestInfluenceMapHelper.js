({
    orgChart: {},
    clickEvent :{},
    dataSource : {},
    metaData: {
        buyingRoleList: [],
        statusList: [],
        focusList: [],
        contactLevelList: []
    },
    scriptLoaded : false,
    buyingRoleList : {},
    statusList : {},
    focusList : {},
    contactLevelList : {},
    focusValues : [],
    focusApis : [],
    focusChars : [],
    contactLevelValues : [],
    filterList: [
        {strApi: "0", strChar: "0", strValue: "Current Account"},
        {strApi: "1", strChar: "1", strValue: "Related Accounts"},
        {strApi: "2", strChar: "2", strValue: "All Accounts"}
    ],

    chartZoom : 1,

    afterScriptHelper : function(component,event){
		// following block will change when we start recieving data from backend
        var action = component.get("c.getInflunceMapRecords");
        action.setParams({
            recordId: "001W000000cabK7IAI",
            fetchFromAccount : false
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state === "SUCCESS"){
                console.log('response : ', response.getReturnValue());
                this.setHelperVariables(response.getReturnValue());
                this.setComponentVariables(component,event);
                if (!component.get("v.isScriptLoaded")) {
                    component.set("v.isScriptLoaded", true);
                    if(this.dataSource && this.dataSource.objInfluenceMap && this.dataSource.objInfluenceMap.Id){
                        this.renderMapOnPage(component,event);
                    }
                    else{
                        this.showPlusButton(component);
                    }
                }
            }
            else{
                //alert("Error in getting data");
                this.showToastMessage(component, "error", "Error while getting data");
            }
        });
        $A.enqueueAction(action);

    },
    renderMapOnPage: function(component, event){
        //console.log("renderMap");
        var element;
        var self = this;
        setTimeout(function() {
            element = $(component.find('chart-Container').getElement());
            self.orgChart = element.orgchart({
                'data': self.dataSource,
                'draggable': true,
                'pan': true,
                'zoom': true,
                'exportButton': true,
                'exportFilename': "InfluenceMap",
                'createNode': function($node, data) {
                    //setting a unique id to every node.
                    $node[0].id = data.objInfluenceMap.Id;

                    //injecting the required HTML.
                    //padding:1px;border:2px solid '+ this.contactStatusColors[this.contactStatusValues.indexOf(data.status)]+'
                    $node[0].innerHTML =
                        '<div aura:id="node" class="nodeDiv slds-box">' +
                        		'<div aria-recordId="'+ data.objInfluenceMap.Id +'">' +
                        			'<p class="emptyDiv"></p>' +
                        			'<h4 aura:id="recordLink" class="recordLink">' + data.objContact.Name + '</h4>' +
                        			'<h5 class="contactTitle tooltip">' + (data.objContact.Title ? (data.objContact.Title.length <= 18 ? data.objContact.Title: (data.objContact.Title.substring(0,18)+ '..'))  : '&nbsp;')+							
									'<span class="tooltiptext">' + (data.objContact.Title ? data.objContact.Title :  '') + '</span>'+'</h5>' +
                        			'<h5>' + (data.objContact.Account.Name ? data.objContact.Account.Name : '&nbsp;') + '</h5>' +
                        			'<div class="slds-grid indicatorsDiv">' +
                        				'<div class="slds-size--4-of-12">' +
                        					'<div aria-class="' + (data.objInfluenceMap.Buying_Role__c ? data.objInfluenceMap.Buying_Role__c : '') + '">'+
                    							'<div class="tooltip">'+
                        							(data.objInfluenceMap.Buying_Role__c ? data.objInfluenceMap.Buying_Role__c.charAt(0) : '') +
                        							'<span class="tooltiptext">' + (data.objInfluenceMap.Buying_Role__c ? data.objInfluenceMap.Buying_Role__c : '') + '</span>'+
                        						'</div>'+
                        					'</div>' +
                        				'</div>' +
                        				'<div class="slds-size--4-of-12 '+(data.objInfluenceMap.Status__c ? data.objInfluenceMap.Status__c : '')+'">' +
                        					'<div aria-class="' + (data.objInfluenceMap.Status__c ? data.objInfluenceMap.Status__c : '') + '">'+
                        						'<div class="tooltip">' +
                        							(data.objInfluenceMap.Status__c ? data.objInfluenceMap.Status__c.charAt(0) : '') +
                        							'<span class="tooltiptext">' + (data.objInfluenceMap.Status__c ? data.objInfluenceMap.Status__c : '') + '</span>'+
                        						'</div>'+
                        					'</div>' +
                        				'</div>' +
                        				'<div class="slds-size--4-of-12">' +
                        					'<div aria-class="' + (data.objInfluenceMap.Focus__c ? self.focusValues[self.focusApis.indexOf(data.objInfluenceMap.Focus__c)] : '') + '">'+
                        						'<div class="tooltip">' +
                        							(data.objInfluenceMap.Focus__c ? data.objInfluenceMap.Focus__c.charAt(0) : '') +
                        							'<span class="tooltiptext">' + (data.objInfluenceMap.Focus__c ? self.focusValues[self.focusApis.indexOf(data.objInfluenceMap.Focus__c)] : '') + '</span>'+
                        						'</div>'+
                        					'</div>' +
                        				'</div>' +
                        				'<div class="extraInfo">'+
                        					'<span>' + (data.objContact.Phone ? data.objContact.Phone : '') + '</span>'+
                        					'<span>' + (data.objContact.Email ? data.objContact.Email : '') + '</span>'+
                        				'</div>' +
                        			'</div>' +
                        			'<div class="slds-grid slds-p-top--xx-small">' +
                        				'<div class="slds-progress-bar tooltip progressBarDiv" aria-valuemin="0" aria-valuemax="100" aria-valuenow="100" role="progressbar">' +
                        					'<span aria-class="' + (data.objInfluenceMap.Level_of_Contact__c ? data.objInfluenceMap.Level_of_Contact__c : '') + '" class="slds-progress-bar__value '+ (data.objInfluenceMap.Level_of_Contact__c ? data.objInfluenceMap.Level_of_Contact__c : '') + '"  title="' + (data.objInfluenceMap.Level_of_Contact__c ? data.objInfluenceMap.Level_of_Contact__c : '') + '">' +
                        						'<span class="tooltiptext">Level of Contact: ' + (data.objInfluenceMap.Level_of_Contact__c ? data.objInfluenceMap.Level_of_Contact__c : '') + '</span>'+
                        					'</span>'+
                        				'</div>'+
                        			'</div>' +
                        			'<div>' +
                        				'<div>' +
                                            '<i id="editNode" class="fa fa-pencil fa-fw" aria-hidden="true"></i>&nbsp;' +
                                            '<i id="deleteNode" class="fa fa-trash fa-fw" aria-hidden="true"></i>' +
                                            '<i id="addNode" class="fa fa-plus fa-fw"  aria-hidden="true"></i>&nbsp;' +
                        				'</div>' +
                        			'</div>';
                }
            })
        }, 100);
        $A.util.addClass(component.find("mapSpinner"), "slds-hide");
    },
    addNewNode : function(component, node){
        //console.log("addNew Node --node : " , node);
        this.linkRecordWithAccountOpportunity(component);
        var nodeData = component.get("v.nodeData");
        if(!this.dataSource || !this.dataSource.objInfluenceMap){
            this.hidePlusButton();
            this.dataSource = {};
            this.dataSource.children = [];
            this.dataSource.objInfluenceMap = nodeData.objInfluenceMap;

            this.dataSource.objContact = nodeData.objContact;
            this.renderMapOnPage(component,event);
            return;
        }
        //Check if the focussed node already has a child or not.
        var hasChild = node.parent().attr('colspan') > 0 ? true : false;
        var oc = this.orgChart;
        //if not, Add a chid Node else add a sibling to the already present child Node(s).
        if(!hasChild){
            var data = {
                'children': [{
                    'objContact' : nodeData.objContact,
                    'objInfluenceMap' : nodeData.objInfluenceMap,
                    'children' : [],
                    'relationship' : "110"
                }]
            }
            oc.addChildren(node, data);
        }
        else{
            //console.log('--closest sibling : ', node.closest('tr').siblings('.nodes').find('.node:first'));
            oc.addSiblings(node.closest('tr').siblings('.nodes').find('.node:first'), {
                'siblings': [{
                    'objContact' : nodeData.objContact,
                    'objInfluenceMap' : nodeData.objInfluenceMap,
                    'children' : [],
                    'relationship': '110',
                    'Id': '12333'
                }]
            })
        }
    },
    updateNode : function(component, node){
        //recordId & parentId will remain as it is in JSON
		var nodeData = component.get("v.nodeData");
        //console.log("updateJSON--event params", nodeData.objInfluenceMap);
        var contactName = nodeData.objContact.Name;
        var contactTitle = nodeData.objContact.Title;
        var contactCompanyName = nodeData.objContact.Account.Name;
        var contactPhone = nodeData.objContact.Phone;
        var contactEmail = nodeData.objContact.Email;
        var contactBuyingRole = nodeData.objInfluenceMap.Buying_Role__c;
        var contactStatus = nodeData.objInfluenceMap.Status__c;
        var contactFocus = nodeData.objInfluenceMap.Focus__c;
        var contactLevel = nodeData.objInfluenceMap.Level_of_Contact__c;

        node[0].childNodes[1].innerText = contactName;
        node[0].childNodes[2].innerText = contactTitle ? contactTitle : ' ';
        node[0].childNodes[3].innerText = contactCompanyName ? contactCompanyName : ' ';
        //have to update buyingRole, Status, Focus values at three different places and change background color as well
        //changing aria-class value (used to populate modal picklists)
        node[0].childNodes[4].childNodes[0].childNodes[0].attributes[0].value = contactBuyingRole;
        node[0].childNodes[4].childNodes[1].childNodes[0].attributes[0].value = contactStatus;
        node[0].childNodes[4].childNodes[2].childNodes[0].attributes[0].value = contactFocus;

        //changing tooltip values
        node[0].childNodes[4].childNodes[0].childNodes[0].childNodes[0].childNodes[1].textContent = contactBuyingRole;
        node[0].childNodes[4].childNodes[1].childNodes[0].childNodes[0].childNodes[1].textContent = contactStatus;
        node[0].childNodes[4].childNodes[2].childNodes[0].childNodes[0].childNodes[1].textContent = contactFocus;
        //changing one alphabet
        node[0].childNodes[4].childNodes[0].childNodes[0].childNodes[0].childNodes[0].textContent = contactBuyingRole.charAt(0);
        node[0].childNodes[4].childNodes[1].childNodes[0].childNodes[0].childNodes[0].textContent = contactStatus.charAt(0);
        node[0].childNodes[4].childNodes[2].childNodes[0].childNodes[0].childNodes[0].textContent = contactFocus.charAt(0);

        //set border-color of Status value, any change in class name should be reflected here
        node[0].childNodes[4].childNodes[1].className = "slds-size--4-of-12 " + contactStatus;
		//extra-info
        node[0].childNodes[4].childNodes[3].childNodes[0].innerText = contactPhone ? contactPhone : '';
        node[0].childNodes[4].childNodes[3].childNodes[1].innerText = contactEmail ? contactEmail : '';

        //saving contacLevel value in aria-class attribute for re-reference, changing color & width of progress bar
        node[0].childNodes[5].childNodes[0].childNodes[0].attributes[0].textContent = contactLevel;
        node[0].childNodes[5].childNodes[0].childNodes[0].attributes[2].textContent = contactLevel;
        node[0].childNodes[5].childNodes[0].childNodes[0].childNodes[0].textContent = 'Level Of Contact : ' + contactLevel;

        //set width of contactLevel progressbar in the node, any change in class name should be reflected here
        node[0].childNodes[5].childNodes[0].childNodes[0].className = "slds-progress-bar__value " + contactLevel;
    },
    getRecord : function(component, recordId, data, record){
        //console.log("getRecord--data : ", data);
        if(!data)
            return;
        if(data.objInfluenceMap.Id == recordId){
            this.getRecordValues(data,record);
        	return;
        }
        else if(data.children){
            for(var i=0; i<data.children.length; i++)
                this.getRecord(component,recordId,data.children[i], record);
        }
    },
    getRecordValues : function(data,record){
        //deep copy object values
        record.objContact = data.objContact;
        record.objInfluenceMap = data.objInfluenceMap;
        /*record.conId = data.conId;
        record.name = data.name;
        record.title = data.title;
        record.companyName = data.companyName;
        record.buyingRole = data.buyingRole;
        record.status = data.status;
        record.focus = data.focus;
        record.contactLevel = data.contactLevel;
        record.phone = data.phone;
        record.mail = data.mail;*/
    },
    updateComponentVariables : function(component,record, action){
        //console.log("updateComponentVariables--record : ", record);
        if(action === "Add"){
            component.set("v.nodeData", {});
            component.set("v.nodeData.objInfluenceMap.Parent_Influencer__c", record.objInfluenceMap.Id);
            component.set("v.contact", {});
            component.set("v.influenceMap", {});
            component.set("v.modalHeader", "Add Existing Contact");
            component.set("v.eventName", "Add");

        }
        else if(action === "Edit"){
            component.set("v.nodeData", record);
            component.set("v.contact", record.objContact);
            component.set("v.influenceMap", record.objInfluenceMap);

            component.set("v.modalHeader", "Edit Contact Info");
            component.set("v.eventName", "Edit");
    	}
    },
    updateJSON : function(component, action){
        var data = this.dataSource;
		var nodeData = component.get("v.nodeData");

        if(action === "Add"){
            // here recordId is actually parent's Id, new nodes will have null in id field in JSON
            var recordId = nodeData.objInfluenceMap.Parent_Influencer__c;
            //console.log("this recordId is being sent : " + recordId);
            this.addChildNode(data, nodeData, recordId);
        }
        else if(action === "Edit"){
            var recordId = nodeData.objInfluenceMap.Id;
            this.updateJSONNode(data, nodeData, recordId);
        }
    },
    addChildNode : function(data, nodeData, recordId){
        if(!data)
            return;
        if(data.objInfluenceMap.Id == recordId){
            var child = {};
            child.objContact = nodeData.objContact;
            child.objInfluenceMap = nodeData.objInfluenceMap;
            child.children = [];

            if(!data.children || data.children.length<=0)
                data.children = [];

            data.children.push(child);
            return;
        }
        else if(data.children){
            for(var i=0; i<data.children.length; i++)
                this.addChildNode(data.children[i],nodeData,recordId);
        }
    },
    updateJSONNode : function(data, nodeData, recordId){
        if(!data)
            return;
        if(data.objInfluenceMap.Id == recordId){
            data.objContact = nodeData.objContact;
            data.objInfluenceMap = nodeData.objInfluenceMap;
            return;
        }
        else if(data.children){
            for(var i=0; i<data.children.length; i++)
                this.updateJSONNode(data.children[i],nodeData,recordId);
        }
    },
    openContactModal : function(component){
        //open Modal
            component.set("v.openContactModal", true);
            //make modal header override salesforce navigation bar
            component.set("v.cssStyle", ".forceStyle .viewport .oneHeader.slds-global-header_container {z-index:0} .forceStyle.desktop .viewport{overflow:hidden}");
    },
    closeContactModal : function(component){
        component.set("v.openContactModal", false);
        //reset salesforce navigation bar css settings
        component.set("v.cssStyle", ".forceStyle .viewport .oneHeader.slds-global-header_container {z-index:5} .forceStyle.desktop .viewport{overflow:visible}");
    },
    deleteNode : function(component, event){
        var oc = this.orgChart;
        var node = this.clickEvent;

        oc.removeNodes(node);
        //$(event.target.parentElement).val("").data("node", "");
        this.orgChart = oc;
        var recordId = component.get("v.nodeData.objInfluenceMap.Id");
        component.set("v.nodeData", {});
        if(this.dataSource.objInfluenceMap.Id == recordId){
            this.dataSource = {};
        	this.showPlusButton(component);
        }
        else{
            this.deleteJSONNode(this.dataSource, recordId);
        }
        this.closeDeleteModal(component);
    },
    goBackToRecord : function(component){
    	var recId = this.metaData.sObjectId;
        var backEvent = $A.get("e.force:navigateToSObject");
        backEvent.setParams({
            recordId: recId,
            isRedirect: true,
            slideDevName: "detail"
        });
        backEvent.fire();
    },
    setComponentVariables : function(component){
        if(this.metaData){
            component.set("v.metaData", this.metaData);
        }
        if(this.dataSource){
            var contactList = [];
            this.populateContactList(this.dataSource, contactList);
            component.set("v.contactList", contactList);
            //console.log("initial contactList : ", component.get("v.contactList"));
        }
    	component.set("v.isInitialized", true);
    },
    setHelperVariables : function(response){
        //populating metaData & dataSource
        this.metaData.sObjectId = response.sObjectId;
        this.metaData.accountId = response.accountId;
        this.metaData.parentAccountId = response.parentAccountId;
        this.metaData.strSObjectName = response.strSObjectName;
        this.metaData.strSObjectType = response.strSObjectType;
        this.metaData.buyingRoleList = response.buyingRoleList;
        this.metaData.statusList = response.statusList;
        this.metaData.focusList = response.focusList;
        this.metaData.contactLevelList = response.contactLevelList;

        this.dataSource = response.data;
        // save focus picklist values in local variables for quick access during add/edit operations
        for(var i=0; i<this.metaData.focusList.length; i++){
            this.focusValues.push(this.metaData.focusList[i].strValue);
            this.focusApis.push(this.metaData.focusList[i].strApi);
            this.focusChars.push(this.metaData.focusList[i].strChar);
        }
        //change values for Contact Level list for easy access
        for(var i=0; i<this.metaData.contactLevelList.length; i++){
            if(this.metaData.contactLevelList[i].strApi == "High")
            	this.metaData.contactLevelList[i].strApi = "100%";
            else if(this.metaData.contactLevelList[i].strApi == "Medium")
            	this.metaData.contactLevelList[i].strApi = "66.67%";
            else if(this.metaData.contactLevelList[i].strApi == "Low")
            	this.metaData.contactLevelList[i].strApi = "33.33%";
        }
        this.buyingRoleList = this.metaData.buyingRoleList;
        this.statusList = this.metaData.statusList;
        this.focusList = this.metaData.focusList;
        this.contactLevelList = this.metaData.contactLevelList;
        this.metaData.filterList = this.filterList;

    },
    showPlusButton : function(component){
        $("#plusDiv").css("display","block");
        $A.util.addClass(component.find("mapSpinner"),"slds-hide");
        if(this.metaData.strSObjectType == "Opportunity")
            component.set("v.isOpportunityObject", "true");
        else
            component.set("v.isOpportunityObject", "false");
    },
    hidePlusButton : function(){
        $("#plusDiv").css("display","none");
    },
    redirectToSelectedContact : function(component, event){
        var recId = event.target.parentElement.parentElement.parentElement.getAttribute("id");
        //object is passed to functions as reference, variables are passed by value
        var contact = {};
        this.getContactId(this.dataSource,recId,contact);
        window.open("/"+contact.Id, "_blank");
        /*var redirect = $A.get("e.force:navigateToURL");
        redirect.setParams({
            url: "/"+contact.id
        });
        redirect.fire();
        */
        /*
        var redirectEvent = $A.get("e.force:navigateToSObject");
        redirectEvent.setParams({
            recordId: contact.id,
            isRedirect: true,
            slideDevName: "detail"
        });
        redirectEvent.fire();
        */
    },
    getContactId : function(dataSource, recordId, contact){
        if(!dataSource)
            return;
        if(dataSource.objInfluenceMap.Id == recordId){
            contact.Id = dataSource.objContact.Id;
            return;
        }
        else if(dataSource.children){
            for(var i=0; i<dataSource.children.length; i++)
                this.getContactId(dataSource.children[i], recordId, contact);
        }
    },
    openDeleteModal : function(component, event){
        component.set("v.showDeleteModal", "true");
        var recordId = event.target.parentElement.parentElement.parentElement.attributes[0].textContent;
        //saving recordId for easy reference in deleteNode function
        var nodeData = {};
        nodeData.objInfluenceMap = nodeData.objContact = {};
        nodeData.objInfluenceMap.Id = recordId;
        component.set("v.nodeData", nodeData);
        //for reference in deleteNode function
        this.clickEvent = $(event.target.parentElement);
        if(recordId == this.dataSource.objInfluenceMap.Id){
            component.set("v.deleteModalMessage", "Do you want to delete entire map?");
        }
        else{
            component.set("v.deleteModalMessage", "Do you want to delete record?");
        }
    },
    closeDeleteModal : function(component){
        component.set("v.showDeleteModal", "false");
        component.set("v.deleteModalMessage", "");
    },
    deleteJSONNode : function(dataSource,recordId){

        if(!dataSource)
            return;
        if(dataSource.children){
            for(var i=0; i<dataSource.children.length; i++){
                if(dataSource.children[i].objInfluenceMap.Id == recordId){
                    dataSource.children.splice(i,1);
                    return;
                }
                else
                    this.deleteJSONNode(dataSource.children[i], recordId);
            }
        }
    },
    validData : function(component) {
		var contactName = component.get("v.nodeData.objContact.Name");
        var contactBuyingRole = component.get("v.nodeData.objInfluenceMap.Buying_Role__c");
        var contactStatus = component.get("v.nodeData.objInfluenceMap.Status__c");
        var contactFocus = component.get("v.nodeData.objInfluenceMap.Focus__c");
        var contactLevel = component.get("v.nodeData.objInfluenceMap.Level_of_Contact__c");

        if(!contactName || !contactBuyingRole || !contactStatus || !contactFocus || !contactLevel){
            //console.log("some fields are incomplete");

            if(!contactName)
                component.set("v.errorMessage","Contact Name can't be empty");
            else if(!contactBuyingRole)
                component.set("v.errorMessage","Buying Role can't be empty");
            else if(!contactStatus)
                component.set("v.errorMessage","Status can't be empty");
            else if(!contactFocus)
                component.set("v.errorMessage","Focus can't be empty");
            else if(!contactLevel)
                component.set("v.errorMessage","Contact Level can't be empty");

            return false;
        }
        return true;
	},
    onModalSave : function(component){
        if(component.get("v.eventName") == "Add"){
            var nodeData = component.get("v.nodeData");
            //console.log("fireSaveEvent-- nodeData : ", nodeData);
            var recordId = nodeData.objInfluenceMap.Id;
            var parentId = "";
            if(nodeData.objInfluenceMap.Parent_Influencer__c)
                parentId = nodeData.objInfluenceMap.Parent_Influencer__c;
            //if first node is being added, then recordid & parentId both values will be blank
            if(!parentId && !recordId){
                //Id length more than 18, parentId will remain blank
                component.set("v.nodeData.objInfluenceMap.Id", "123456789123456789" + Math.floor(Math.random()*1000));
                component.set("v.nodeData.objInfluenceMap.Parent_Influencer__c", "");
            }
            else if(parentId && !recordId){
                component.set("v.nodeData.objInfluenceMap.Id", parentId + Math.floor(Math.random()*1000));
            }
        }
    },
    saveContact : function(component){
        //event called by modal component & event name is add
        if(component.get("v.eventName") == "Add"){
            //adding first node
            if(!this.dataSource || !this.dataSource.objInfluenceMap){
                this.addNewNode(component,{});
            }
            else{
                //to reach div.node (the top node)
                var node = $(this.clickEvent.target.parentElement.parentElement.parentElement.parentElement.parentElement);
                this.addNewNode(component, node);
                this.updateJSON(component, "Add");
            }
        }
        else if(component.get("v.eventName") == "Edit"){
            var node = $(this.clickEvent.target.parentElement.parentElement.parentElement);
            this.updateNode(component, node);
            this.updateJSON(component, "Edit");
        }
        this.closeContactModal(component);
    },
    populateContactList : function(dataSource, contactList){
        if(!dataSource)
            return;
        if(dataSource.objContact){
            contactList.push(dataSource.objContact.Id);
            if(dataSource.children){
                for(var i=0; i<dataSource.children.length; i++)
                    this.populateContactList(dataSource.children[i], contactList);
            }
        }
    },
    clearLookupField : function(component){
        component.set("v.nodeData.objContact", {});
        var lookupComponent = component.find("lookupComponent");
        lookupComponent.clearFromParent();
    },
    updateContactList : function(component, event){
        if(event == "Delete"){
            if(!this.dataSource)
                component.set("v.contactList", []);
        	var contactList = component.get("v.contactList");
            if(!contactList)
                return;
            var recordId = component.get("v.nodeData.objInfluenceMap.Id");
            var contact = {};
            this.getContactId(this.dataSource, recordId, contact);

            for(var i=0; i<contactList.length; i++){
                if(contactList[i] == contact.Id){
                    contactList.splice(i,1);
                    component.set("v.contactList", contactList);
                    break;
                }
            }
        }


    },
    prepareFinalData : function(jsonData, hierarchyData , parentId){
        if(!hierarchyData)
            return;

        this.getDataFromDataSource(this.dataSource, jsonData, hierarchyData.id, parentId);
        if(hierarchyData.children){
            for(var i=0; i<hierarchyData.children.length; i++){
                var child = {};
                jsonData.children.push(child);
                this.prepareFinalData(child, hierarchyData.children[i], hierarchyData.id);
            }
        }
    },
    getDataFromDataSource : function(dataSource, jsonData, recordId, parentId){
        if(!dataSource)
            return;

        if(dataSource.objInfluenceMap.Id == recordId){
            jsonData.objInfluenceMap = dataSource.objInfluenceMap;
            jsonData.objInfluenceMap.Parent_Influencer__c = parentId;
            //console.log("jsonData.objInfluenceMap : ", jsonData.objInfluenceMap);
            jsonData.objContact = dataSource.objContact;
            jsonData.children = [];
            return;
        }
        else if(dataSource.children){
            for(var i=0; i<dataSource.children.length; i++)
                this.getDataFromDataSource(dataSource.children[i], jsonData, recordId, parentId);
        }
    },
    finalSaveAction : function(component, jsonData){
        var action = component.get("c.saveInfluenceMapRec");
        action.setParams({
            "jsonValue" : JSON.stringify(jsonData),
            "recordId" : this.metaData.sObjectId
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if(state === "SUCCESS"){
                //alert("Data Saved");
                this.showToastMessage(component, "success", "Data saved successfully");
            }
            else{
                this.showToastMessage(component, "error", "Internal Error happened while saving records, please contact Administrator");
            }
        });
        $A.enqueueAction(action);
    },
    linkRecordWithAccountOpportunity : function(component){
        if(this.metaData.strSObjectType == "Opportunity")
        	component.set("v.nodeData.objInfluenceMap.Opportunity__c", this.metaData.sObjectId);
        else if(this.metaData.strSObjectType == "Account")
        	component.set("v.nodeData.objInfluenceMap.Account__c", this.metaData.sObjectId);
        else if(this.metaData.strSObjectType == "Contact")
        	component.set("v.nodeData.objInfluenceMap.Account__c", this.metaData.accountId);

    },
    showToastMessage : function(component, toastType, toastMessage){
        var showToastEvent = $A.get("e.force:showToast");
        showToastEvent.setParams({
            type: toastType,
            message: toastMessage,
            mode: "dismissible"
        });
        showToastEvent.fire();
	}
 })