({
    toggleClass: function(component, componentId, className) {
        var modal = component.find(componentId);
        $A.util.removeClass(modal, className + 'hide');
        $A.util.addClass(modal, className + 'open');
    },
    toggleClassInverse: function(component, componentId, className) {
        var modal = component.find(componentId);
        $A.util.addClass(modal, className + 'hide');
        $A.util.removeClass(modal, className + 'open');
    },
    /* 
     * function name : navToRelatedList
     * return value  : none
     * description   : helpermethod to redirect to view all related list view 
     */ 
    navToRelatedList: function(component, event) {
        var relatedListEvent = $A.get("e.force:navigateToRelatedList");
        relatedListEvent.setParams({
            "relatedListId": "POC_Inventory_Reservations__r",
            "parentRecordId": component.get("v.recordId")
        });
        relatedListEvent.fire();
    },
    /* 
     * function name : navigateToSObjectDetailView
     * return value  : none
     * description   : Helpermethod to redirect to Sobject detail view
     */ 
    navigateToSObjectDetailView: function(component, event) {
        var recId = event.target.getAttribute("aria-recordId");
        console.log('e-->', event.target.getAttribute("aria-recordId"));
        var navEvt = $A.get("e.force:navigateToSObject");
        navEvt.setParams({
            "recordId": recId,
            "slideDevName": "detail"
        });
        navEvt.fire();
    },
})