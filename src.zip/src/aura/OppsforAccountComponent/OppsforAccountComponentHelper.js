({
	queryRows : function(component, page, sOrder) {
        var action = component.get("c.getSobjects");
        //console.log("=== fields ===="+fields);
		var params = { "columnfields": component.get("v.columnfields"), "objName": component.get("v.object"), "currentPage": page, "lim": component.get("v.pagelimit") || 10
                      ,"sortField" : component.get("v.sortField"), "sortOrder" :  sOrder || "asc" , "whereCls":component.get("v.whereclause"),"filterBy":component.find("InputSelectDynamic").get("v.value") 
                     ,"fldName":component.get("v.linkField"),"curId":component.get("v.recordId"),"relatedObjName":component.get("v.objName")};
        console.log(JSON.stringify(params));
        action.setParams(params);
        action.setCallback(this, function(response) {
            console.log(response.getState());
            if (response && response.getState() === "SUCCESS" && component.isValid()) {
            	var recordset = response.getReturnValue();
                if (component.get("v.columns").length <= 0) {
                	component.set("v.columns", recordset.columnHeader);   
                }
                console.log(recordset.rows);
                console.log(recordset.size);
                
                component.set("v.results", recordset.rows);
                component.set("v.resultsetsize", recordset.size);                
                console.log(component.get("v.results").length);
                
            }
            component.set("v.showspinner", false);
        });
        $A.enqueueAction(action);
	},
    getSortOrder : function(cmp, changeorder) {
        if (changeorder && changeorder === true) {
        	if (cmp.get("v.ascDescVal") === "asc") {
                cmp.set("v.ascDescVal", "desc");
            } else if (cmp.get("v.ascDescVal") === "desc") {
                cmp.set("v.ascDescVal", "asc");
            } else {
                cmp.set("v.ascDescVal", "desc");
            }    
        }
        return cmp.get("v.ascDescVal");
	}
})