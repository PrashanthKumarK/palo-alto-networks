({
    doInit: function(cmp,event,helper) {
		//
        
        //
         var action2 = cmp.get("c.getSobjectName");
        action2.setParams({
            "curId" : recId
        });
        //Set up the callback
        action2.setCallback(this, function(actionResult) {
            console.log("RAAJ :"+actionResult.getReturnValue());
            cmp.set("v.objName", actionResult.getReturnValue());
        });
        $A.enqueueAction(action2);
        
        if (cmp.isValid()) {
            //helper.queryFieldsFomrat(cmp);
            var whereCls = cmp.get("v.whereclause");
            if (cmp.get("v.isRelatedList") === true && whereCls && whereCls.trim().length > 0) {
                whereCls = whereCls.toLowerCase().replace('{recordid}', '\''+cmp.get("v.recordId")+'\'');
                cmp.set("v.whereclause", whereCls);
            }
            helper.queryRows(cmp, 0, helper.getSortOrder(cmp, false));
        }

        var action = cmp.get("c.getOppStages");
        var inputsel = cmp.find("InputSelectDynamic");
        var opts=[];
        action.setCallback(this, function(a) {
            for(var i=0;i< a.getReturnValue().length;i++){
                opts.push({"class": "optionClass", label: a.getReturnValue()[i], value: a.getReturnValue()[i]});
            }
            inputsel.set("v.options", opts);
            
        });
        $A.enqueueAction(action); 
        var recId = cmp.get("v.recordId");
        var action1 = cmp.get("c.getRelationName");
        var obj = cmp.get("v.object")
        var linkField = cmp.get("v.linkField");
        var objName   = cmp.get("v.objName");
        console.log("RAAJ :"+recId+obj);
        action1.setParams({
            "fldName": linkField,
            "curId" : recId,
            "objName" : objName
        });
        //Set up the callback
        action1.setCallback(this, function(actionResult) {

            cmp.set("v.accName", actionResult.getReturnValue());
        });        
        $A.enqueueAction(action1);
    }, 
    onSelectChange : function(cmp, event, helper) {
        cmp.set("v.showspinner", true);
        console.log("=== RAAJ inputSel ===="+cmp.find("InputSelectDynamic").get("v.value"));
        helper.queryRows(cmp, 0, helper.getSortOrder(cmp, false));       
    },    
    pagerecords : function (cmp,event,helper) {
        if (cmp.isValid()) {
            cmp.set("v.page", event.getParam("pagevalue"));
            helper.queryRows(cmp, cmp.get("v.page") || 0, helper.getSortOrder(cmp, false));
        }
    },
    customSort : function(cmp,event,helper) {
        if (cmp.isValid()) {
            cmp.set("v.sortField", event.getParam("fieldid"));
            cmp.set("v.page", event.getParam("pagevalue"));
            helper.queryRows(cmp, cmp.get("v.page") || 0, helper.getSortOrder(cmp, true));
        }
    },
    showSpinner : function (component, event, helper) {
        if (component.isValid()) component.set("v.showspinner", true); 
    },
    hideSpinner : function (component, event, helper) {
        if (component.isValid()) component.set("v.showspinner", false);
    }, 
    showEdit : function (component, event, helper) {
        try {
            if (component.isValid()) {
                component.set("v.edit", 1);
                helper.queryRows(component, component.get("v.page") || 0, helper.getSortOrder(component, false));        
            }
        } catch (e) {
            console.log("mode == "+e);
            throw new Error("error occured refresh page!!"+e);    
        }
    },
    cancelEdit : function (component, event, helper) {
        try {
            if (component.isValid()) {
                component.set("v.edit", 0);
                helper.queryRows(component, component.get("v.page") || 0, helper.getSortOrder(component, false));	
            } 
        } catch (e) {
            console.log("mode == "+e);
            throw new Error("error occured refresh page!!");
        }
    },
    /* 
     * function name : navToRecord
     * return value  : none
     * description   : method to redirect user to record detail view
     */ 
    navToRecord : function (component, event, helper) {
        var selectedItem = event.currentTarget;
        var recId = selectedItem.dataset.record;
        console.log('Seleceted record:'+recId);
        var navEvt = $A.get("e.force:navigateToSObject");
        navEvt.setParams({
            "recordId": recId
        });
        navEvt.fire();
    }    
})