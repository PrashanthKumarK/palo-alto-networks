({
	callWebService : function(component,event,helper) {
        try{
        
        var recordId = component.get("v.recordId");
        var action = component.get("c.callPushToSapMethod");
        action.setParams({
            recordId : recordId
        });
        
        $A.enqueueAction(action);
        $A.get("e.force:closeQuickAction").fire();
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": "/"+recordId
        });
        urlEvent.fire(); 
        }catch(e){
           var msgString = 'There was an error pushing record to SAP.\n\n'+e.message+' \n\n '+'Click OK to continue.\n\n';
           window.alert(msgString);
              
        }
         
        
	}
})