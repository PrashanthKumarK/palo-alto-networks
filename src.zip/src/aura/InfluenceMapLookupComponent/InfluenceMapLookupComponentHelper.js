({
    /* 	   ***********************************************************************************************************************
	 *     ########## PARAMETERS INDICATE variables/objects other than COMPONENT, EVENT, HELPER passed to the FUNCTION ##########
     * 	   *********************************************************************************************************************** 
     */
    /* 
     * function name : searchHelper
     * parameters    :  searchKeyword (text typed in the lookup field)
     * return value  :  
     * description   : calls backend function to get contacts based on account fiter value & searchKeyword, displays lookup results
     */ 
    searchHelper: function(component, searchKeyword) {
        // call the apex class method
        var action = component.get("c.getContacts");
        var filterValue = component.get("v.filterValue");
        var filterField = component.get("v.filterField");
        var accountId = component.get("v.accountId");
        var apexAccountId = component.get("v.apexAccountId");
        //filterField = "AccountId", is defaulted in Lookup Component definiton inside parent component
        if(filterValue == 1)
            filterField = "Account.ApexAccountId__c";
            
        component.set("v.message", "");
        //console.log("values being sent to apex, searchKeyword : ", searchKeyword, ", filterField : ", filterField, ", filterValue : ", filterValue, ", accountId : ", accountId, ", apexAccountId : ", apexAccountId, ", existingContactList : ", component.get("v.existingContactList"));
        // set params to method
		var filterVal = filterValue.toString(); //issue in sending integer value to apex method
        action.setParams({
            "searchKeyword" : searchKeyword,
            "filterField" : filterField,
            "filterValue" : filterVal,
            "accountId" : accountId,
            "apexAccountId" : apexAccountId,
            "existingContactList" : component.get("v.existingContactList")
        });
        // set a callBack
        action.setCallback(this, function(response) {
            var state = response.getState();
            //console.log("getContacts response : ", response.getReturnValue());
            if (state === "SUCCESS") {
                var contacts = response.getReturnValue();
                // if storeResponse size is equal 0 ,display No Result Found... message on screen.                }
                if (!contacts || contacts.length == 0) {
                    component.set("v.message", "No Result Found...");
                }
                // set searchResult list with return value from server.
                component.set("v.listOfContacts", contacts);
            }
            else{
                component.set("v.message", "Internal error occurred");
            }

        });
        // enqueue the Action
        $A.enqueueAction(action);

    },
    /* 
     * function name : openSearchResults
     * parameters    : none 
     * return value  : none
     * description   : Opens results pane below lookup field after apex call returns results
     */ 
    openSearchResults : function(component){
        var forOpen = component.find("searchRes");
        $A.util.addClass(forOpen, "slds-is-open");
        $A.util.removeClass(forOpen, "slds-is-close");
    },
    /* 
     * function name : closeSearchResults
     * parameters    : none
     * return value  : none 
     * description   : Closes search result when focus is lost on lookup field/ user selects one Contac
     */ 
    closeSearchResults : function(component){
        component.set("v.listOfContacts", null);
        var forclose = component.find("searchRes");
        $A.util.addClass(forclose, "slds-is-close");
        $A.util.removeClass(forclose, "slds-is-open");
    },
    /* 
     * function name : resetComponent
     * parameters    : none
     * return value  : none
     * description   : reset values in the lookup component, when Account Filter value changes
     */ 
    resetComponent : function(component){
        //added on 10th jan '18 for testing
        component.set("v.selectedContact", {});
        // call the event
        var compEvent = component.getEvent("oSelectedContactEvent");
        
        // set the Selected sObject Record to the event attribute.
        compEvent.setParams({
            "contact" : {}
        });
        // fire the event
        //compEvent.fire();
        var pillTarget = component.find("lookup-pill");
        var lookUpTarget = component.find("lookupField");

        $A.util.addClass(pillTarget, "slds-hide");
        $A.util.removeClass(pillTarget, "slds-show");

        $A.util.addClass(lookUpTarget, "slds-show");
        $A.util.removeClass(lookUpTarget, "slds-hide");

        component.set("v.searchKeyword", "");
        component.set("v.listOfContacts", []);
        component.set("v.selectedContact", {});
    },
    /* 
     * function name : setContactData
     * parameters    : none
     * return value  : none
     * description   : populate lookup field in "Exisiting Contact" tab after a new Contact is inserted
     */ 
    setContactData : function(component, event){
		// get the selected Contact record from the COMPONENT event
		var contact = event.getParam("contact");
        component.set("v.selectedContact", contact);
        this.closeSearchResults(component);

        var forclose = component.find("lookup-pill");
        $A.util.addClass(forclose, "slds-show");
        $A.util.removeClass(forclose, "slds-hide");

        var lookUpTarget = component.find("lookupField");
        $A.util.addClass(lookUpTarget, "slds-hide");
        $A.util.removeClass(lookUpTarget, "slds-show");
    },
    /* 
     * function name : updateExistingContactList
     * parameters    : none
     * return value  : none
     * description   : updates existingContactList to avoid duplicates in the map
     */ 
    updateExistingContactList : function(component, event){
        if(!component.get("v.selectedContact.Id"))
            return;
        var existingContactList = component.get("v.existingContactList");

        if(event == "Clear" && existingContactList){
            for(var i=0; i< existingContactList.length; i++){
                if(existingContactList[i] == component.get("v.selectedContact.Id")){
                    component.set("v.clearedContactId", component.get("v.selectedContact.Id"));
                    existingContactList.splice(i,1);
                	break;
                }
            }
        }
        component.set("v.existingContactList", existingContactList);
        //console.log("contact List : ", existingContactList);
    }
})