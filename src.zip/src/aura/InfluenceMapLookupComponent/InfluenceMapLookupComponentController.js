({
    /* 
     * function name : onfocus
     * return value  : none
     * description   : used to display Contact records based on Account Filter on focus of lookup field
     */ 
    onfocus: function(component, event, helper) {
        $("form").attr("autocomplete", "off");
        var forOpen = component.find("searchRes");
        $A.util.addClass(forOpen, "slds-is-open");
        $A.util.removeClass(forOpen, "slds-is-close");
        // Get Default 5 Records order by createdDate DESC
        var searchKeyword = "";
        helper.searchHelper(component, searchKeyword);
    },
    /* 
     * function name : keyPressController
     * return value  : none
     * description   : Updates Contact Lookup suggestion based on keypress
     */ 
    keyPressController: function(component, event, helper) {
        // get the search Input keyword
        var searchKeyword = component.get("v.searchKeyword");
        // check if getInputKeyWord size id more then 0 then open the lookup result List and
        // call the helper
        // else close the lookup result List part.
        if (searchKeyword.length > 0) {
            helper.openSearchResults(component);
            helper.searchHelper(component, searchKeyword);
        }
        else {
            helper.closeSearchResults(component);
        }

    },
    /* 
     * function name : clear
     * return value  : none
     * description   : clear lookup field value either on explicit lookup clear button click,
     * 					 or on change of Account Filter picklist value
     */ 
    clear: function(component, event, helper) {
        helper.updateExistingContactList(component, "Clear");
        helper.resetComponent(component);
    },
    /* 
     * function name : selectedContactEvent
     * return value  : none
     * description   : updates component variable values, when the user selects one contact from suggestions
     */ 
    selectedContactEvent: function(component, event, helper) {
        helper.setContactData(component, event);
		//helper.updateExistingContactList(component, "Save");
    },
    /* 
     * function name : hideSpinner
     * return value  : none
     * description   : hide modal spinner when any action completes
     */ 
    hideSpinner: function(component, event, helper) {
        var spinner = component.find("spinner");
        var evt = spinner.get("e.toggle");
        evt.setParams({
            isVisible: false
        });
        evt.fire();
    },
    /* 
     * function name : showSpinner
     * return value  : none
     * description   : show spinner when a backend function is invoked from modal
     */ 
    showSpinner: function(component, event, helper) {
        var spinner = component.find("spinner");
        var evt = spinner.get("e.toggle");
        evt.setParams({
            isVisible: true
        });
        evt.fire();
    },
    /* 
     * function name : setSelectedContact
     * return value  : none
     * description   : populates lookup field upon contact insert action
     */ 
    setSelectedContact : function(component, event, helper){
        var params = event.getParam("arguments");
        var contact = params.contact
        //console.log("received contact in Lookup cmp : ", contact);
        if(contact && contact.Id)
        	component.set("v.selectedContact", contact);
        	var compEvent = component.getEvent("oSelectedContactEvent");
            // set the Selected sObject Record to the event attribute.
            compEvent.setParams({
                "contact" : contact
            });
            // fire the event
            compEvent.fire();
    },
    /* 
     * function name : hideResults
     * return value  : none
     * description   : Closes search result when lookup field looses focus
     */ 
    hideResults : function(component, event, helper){
        //helper.closeSearchResults(component);
        //affecting contactselect action
    }
})