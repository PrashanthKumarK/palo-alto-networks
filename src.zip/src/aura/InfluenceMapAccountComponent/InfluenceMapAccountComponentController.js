({
    doInit: function(component, event, helper) {
        //show spinner
        if(window.jQuery && !component.get("v.isInitialized")){
            helper.afterScriptHelper(component, event);
        }

    },
    /*
     *
     */
    afterScript : function(component, event, helper){
        if(window.jQuery && !component.get("v.isInitialized")){
            helper.afterScriptHelper(component, event);
        }

    },
    /* action : function
     * This function will catch the event on the basis of button click- Add/Delete and execute the Action.
     *
     */
    action: function(component, event, helper) {
        if (event.target.id == "editNode" || event.target.id == "addNode") {
            //save event's context in a variable for future use
            helper.clickEvent = event;
            var node = $(event.target.parentElement.parentElement.parentElement);
            //first attribute of node should be aria-recordId
            var recordId = node[0].attributes[0].textContent;
            //get record data from JSON data
            var record = new Object();
            helper.getRecord(component, recordId, helper.dataSource, record);
            if (event.target.id == "addNode") {
                //reset input fields values
                helper.updateComponentVariables(component,record,"Add");
            }
            else if(event.target.id == "editNode"){
                helper.updateComponentVariables(component,record,"Edit");
            }
            helper.openContactModal(component);
        }
        else if (event.target.id == "deleteNode") {
            helper.openDeleteModal(component, event);
        }
        else if(event.target.getAttribute("class") == "recordLink"){
            //add logic to stop redirecting for newly created records
        	helper.redirectToSelectedContact(component, event);
		}
    },
    closeContactModal : function(component, event, helper){
        helper.closeContactModal(component);
    },
    saveContact : function(component, event, helper){
        //event called by modal component & event name is add
        if(event.getParam("eventName") == "Add"){
            //adding first node
            if(!helper.dataSource || !helper.dataSource.id){
                helper.addNewNode(component,event,{});
            }
            else{
                //to reach div.node (the top node)
                var node = $(helper.clickEvent.target.parentElement.parentElement.parentElement.parentElement.parentElement);
                helper.addNewNode(component,event,node);
                helper.updateJSON(component,event,"Add");
            }
            console.log("dataSource : ", helper.dataSource);
        }
        else if(event.getParam("eventName") == "Edit"){
            var node = $(helper.clickEvent.target.parentElement.parentElement.parentElement);
            helper.updateNode(component, event, node);
            helper.updateJSON(component,event,"Edit");
            console.log("dataSource : ", helper.dataSource);
        }
        helper.closeContactModal(component);
    },
    goBack : function(component,event,helper){
    	helper.goBackToRecord(component);
    },
    saveMapData : function(component, event, helper){
        //on data load, make <Id:Data> pair for each record
        //update those records on Edit action
        //add new <Id:Data> pair on Add action
        //on Save action, get Hierarchy using orgChart,
        //and make JSON by adding values from <Id, Data> pairs
    },
    addFirstNode : function(component, event, helper){
        //alert("Work in progress");
        var record = {};
        record.id = "";
        helper.updateComponentVariables(component,record,"Add");
        helper.openContactModal(component);
    },
    closeDeleteModal : function(component, event, helper){
        helper.closeDeleteModal(component);
    },
    deleteContact : function(component, event, helper){
        helper.deleteNode(component, event);
    }
})