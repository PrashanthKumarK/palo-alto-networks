({
	doInit : function(component, event, helper) {
        try{
            var recId = component.get("v.recordId");
        var action = component.get("c.getCPQUserWithApproverRecord");
        action.setParams({
            "recordId": component.get("v.recordId")
        });
                
        // Register the callback function
        action.setCallback(this, function(response) {
            var status = response.getState();
            var data = response.getReturnValue();
            var urlEvent = $A.get("e.force:navigateToURL");
            if (status === 'SUCCESS'){
            	
                $A.get("e.force:refreshView").fire();
                var dismissActionPanel = $A.get("e.force:closeQuickAction");
                dismissActionPanel.fire();
            }
            
        });
        $A.enqueueAction(action);
        }catch(e){
            throw new Error("Unexpected error occured! Try refreshing the page. If it continues to happen please contact your System Admin");
            console.error(e);    
        }
	}
})