({
	doInit : function(component, event, helper) {
        try{
        //Id of the current Lead Record
        var recId = component.get("v.recordId");
        var action = component.get("c.getRiskReportOnLead");   
        // set param to method   
        action.setParams({
            "leadId": component.get("v.recordId")
        });
                
        // Register the callback function
        action.setCallback(this, function(response) {
            var status = response.getState();
            var dataVal = response.getReturnValue();
            var urlEvent = $A.get("e.force:navigateToURL");
             if(dataVal!=null){
                // set the url to be directed to
            	urlEvent.setParams({
                    "url":dataVal
                });  
                 console.log('Hormese'+dataVal);
                urlEvent.fire();   
            }else{
                var err  ="There was an error inserting Risk Report Audit record"; 
                alert(err);
            }
            var dismissActionPanel = $A.get("e.force:closeQuickAction");
            dismissActionPanel.fire();
        });
        // enqueue the Action
        $A.enqueueAction(action);
        }catch(e){
            throw new Error("Unexpected error occured! Try refreshing the page. If it continues to happen please contact your System Admin");
            console.error(e); 
        }
	}
})