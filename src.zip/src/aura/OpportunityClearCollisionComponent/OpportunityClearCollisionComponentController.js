({
	doInit:function(component,event,helper){
		//get the record Id
		var recId=component.get("v.recordId");
		// Set default value to show message
		component.set("v.displayMessage", false);
        console.log('recordId : ' + recId);
		//method getStageNumeric from OpptyResetCollisionController
		var action=component.get("c.getStageNumeric");
		//set the parameter
		action.setParams({
			"oppId":recId
		});
		//Register the callback function
		action.setCallback(this,function(response){
            var state=response.getState();
            if(state==="SUCCESS"){
                var data = response.getReturnValue();
                console.log('data'+data.Stage_Numeric__c);
				if(data.Stage_Numeric__c != 0){
					component.set("v.displayMessage", true);
					component.set("v.message", "This action is not allowed in this opportunity stage.");
                }else{
                	//method resetCollision from OpptyResetCollisionController
                    var action1=component.get("c.resetCollision");
                    action1.setParams({
                        "OppId":recId
                    });
                    //Register the callback function
                    action1.setCallback(this,function(a){
                        var value=a.getReturnValue();
                        console.log('value'+value);
                        if(value=='Success'){
							component.set("v.displayMessage", true);
							component.set("v.message", "Collision Cleared!");
						}
                    });
                    // Action Call
                    $A.enqueueAction(action1);
                } 
            }	
		});
		// Action Call
		$A.enqueueAction(action); 
	}
})