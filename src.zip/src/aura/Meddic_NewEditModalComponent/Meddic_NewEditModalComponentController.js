({
    createNewDescription : function(component, event, helper){
       helper.createNewDescription(component, event, helper);
        
    }, 
	close : function(component, event, helper) {
        component.set("v.SearchKeyWord",'');
		component.set("v.show", false);
	}, 
	fetchEditContact : function(component, event, helper) {
		if(component.get("v.editrecord") && component.get("v.show") && component.get("v.stakeholerId") != null && component.get("v.stakeholerId") != '')
        {
            var action = component.get("c.getContactDetails"); 
            action.setParams({
                "contactId" : component.get("v.stakeholerId")
            });
            action.setCallback(this, function(a) {
                if (a.getState() === "SUCCESS") {                   
                    component.set("v.selectedRecord" , a.getReturnValue());       
       				helper.adjustPill(component, event, helper);                    
                }
            }); 
            $A.enqueueAction(action);
        }
	},
    keyPressController : function(component, event, helper) {
      // get the search Input keyword   
		var getInputkeyWord = component.get("v.SearchKeyWord");
      // check if getInputKeyWord size id more then 0 then open the lookup result List and 
      // call the helper 
      // else close the lookup result List part.   
        if( getInputkeyWord.length > 0 ){
             var forOpen = component.find("searchRes");
               $A.util.addClass(forOpen, 'slds-is-open');
               $A.util.removeClass(forOpen, 'slds-is-close');
            helper.searchHelper(component,event,getInputkeyWord);
        }
        else{  
            component.set("v.listOfSearchRecords", null ); 
             var forclose = component.find("searchRes");
               $A.util.addClass(forclose, 'slds-is-close');
               $A.util.removeClass(forclose, 'slds-is-open');
          }
         
	},
  
  // function for clear the Record Selaction 
    clear :function(component,event,heplper){
      
         var pillTarget = component.find("lookup-pill");
         var lookUpTarget = component.find("lookupField"); 
        
         $A.util.addClass(pillTarget, 'slds-hide');
         $A.util.removeClass(pillTarget, 'slds-show');
        
         $A.util.addClass(lookUpTarget, 'slds-show');
         $A.util.removeClass(lookUpTarget, 'slds-hide');
      
         component.set("v.SearchKeyWord",null);
         component.set("v.listOfSearchRecords", null );
    },
    
  // This function call when the end User Select any record from the result list.   
    handleComponentEvent : function(component, event, helper) {
     
    // get the selected Account record from the COMPONETN event 	 
       var selectedAccountGetFromEvent = event.getParam("accountByEvent");
	   component.set('v.stakeholerId',selectedAccountGetFromEvent.Id);
        
	   component.set("v.selectedRecord" , selectedAccountGetFromEvent); 
       
       helper.adjustPill(component, event, helper);
      
	},
  // automatically call when the component is done waiting for a response to a server request.  
    hideSpinner : function (component, event, helper) {
        var spinner = component.find('spinner');
        if(spinner != undefined)
        {
            var evt = spinner.get("e.toggle");
            evt.setParams({ isVisible : false });
            evt.fire();  
        }
    },
 // automatically call when the component is waiting for a response to a server request.
    showSpinner : function (component, event, helper) {
        var spinner = component.find('spinner');
        if(spinner != undefined)
        {
            var evt = spinner.get("e.toggle");
            evt.setParams({ isVisible : true });
            evt.fire();    
        }
    }
})