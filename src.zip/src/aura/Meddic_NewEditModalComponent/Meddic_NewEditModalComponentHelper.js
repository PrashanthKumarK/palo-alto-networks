({
	createNewDescription : function(component, event, helper) {
        
            if(component.get('v.description') !== ''){
            var action = component.get("c.createNewDescriptionctrl"); 
            action.setParams({
                "descriptionName" : component.get('v.description'),
                "descriptionid" :  component.get('v.recorddetailsid'),
                "selectedTitle" : component.get('v.selectedTitle'),
                //"stakeholder" : component.get('v.stakeholerName'),
                "stakeid" : component.get('v.stakeholerId'),
                "parentId" : component.get('v.recordId')
            });
            action.setCallback(this, function(a) {
                if (a.getState() === "SUCCESS") {
                    
                  
                    component.set('v.show', false);
                    component.set('v.description', '');
                    component.set("v.SearchKeyWord",'');
                     component.getEvent("refreshform").fire();
                    
                }
            }); 
            $A.enqueueAction(action);
        } else {
                 alert('Error : ' + JSON.stringify(errors));
        }

		
	},
    searchHelper : function(component,event,getInputkeyWord) {
	  // call the apex class method 
     var action = component.get("c.fetchContact");
      // set param to method  
        action.setParams({
            'searchKeyWord': getInputkeyWord,
            'opptyId' : component.get("v.recordId")
          });
        
      // set a callBack    
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var storeResponse = response.getReturnValue();
              // if storeResponse size is equal 0 ,display No Result Found... message on screen.
                if (storeResponse.length == 0) {
                    component.set("v.Message", 'No Result Found...');
                } else {
                    component.set("v.Message", 'Search Result...');
                }
                
                // set searchResult list with return value from server.
                component.set("v.listOfSearchRecords", storeResponse);
            }
 
        });
      // enqueue the Action  
        $A.enqueueAction(action);
    
	},
    adjustPill : function(component,event,helper) {
         var forclose = component.find("lookup-pill");
           $A.util.addClass(forclose, 'slds-show');
           $A.util.removeClass(forclose, 'slds-hide');
      
        
        var forclose = component.find("searchRes");
           $A.util.addClass(forclose, 'slds-is-close');
           $A.util.removeClass(forclose, 'slds-is-open');
        
        var lookUpTarget = component.find("lookupField");
            $A.util.addClass(lookUpTarget, 'slds-hide');
            $A.util.removeClass(lookUpTarget, 'slds-show');  
    }
})