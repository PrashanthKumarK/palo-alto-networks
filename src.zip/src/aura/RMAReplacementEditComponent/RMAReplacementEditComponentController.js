({
	doInit : function(component, event, helper) {
        try{
        //Current Record ID
        var recId = component.get("v.recordId");
        var urlEvent = $A.get("e.force:navigateToURL");	
        //method getRMARecordId from RMAReplacementItemController
        var action = component.get("c.getRMARecordId");

        action.setParams({
            "recordId": component.get("v.recordId")
        });
                
        // Register the callback function
        action.setCallback(this, function(response) {
            var status = response.getState();
            var data = response.getReturnValue();
            var urlEvent = $A.get("e.force:navigateToURL");
            var RId = data.RMA_Id__c;
            if (typeof(srcUp) == 'function') { 
                // set the url to be directed to
                urlEvent.setParams({
                    "url": "/apex/RMAEdit?isdtp=vw&id="+RId
                });   
                urlEvent.fire();
            }else{ 
                // set the url to be directed to
            	urlEvent.setParams({
                    "url": "/apex/RMAEdit?id="+RId
                });   
                urlEvent.fire();
            }
            
        });
        // enqueue the Action
        $A.enqueueAction(action);
        }catch(e){
           throw new Error("Unexpected error occured! Try refreshing the page. If it continues to happen please contact your System Admin");
            console.error(e);    
        }
	}
})