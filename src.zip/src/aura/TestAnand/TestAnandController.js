({
    doInit: function(component, event, helper) {
        //show spinner
        if(window.jQuery && !component.get("v.isInitialized")){
            helper.afterScriptHelper(component, event);
        }

    },
    afterScript : function(component, event, helper){
        if(window.jQuery && !component.get("v.isInitialized")){
            helper.afterScriptHelper(component, event);
        }

    },
    /* action : function
     * This function will catch the event on the basis of button click- Add/Delete and execute the Action.
     *
     */
    action: function(component, event, helper) {
        if (event.target.id == "editNode" || event.target.id == "addNode") {
            //save event's context in a variable for future use
            helper.clickEvent = event;
            var node = $(event.target.parentElement.parentElement.parentElement);
            //first attribute of node should be aria-recordId
            var recordId = node[0].attributes[0].textContent;
            //get record data from JSON data
            var record = new Object();
            helper.getRecord(component, recordId, helper.dataSource, record);
            if (event.target.id == "addNode") {
                //reset input fields values
                helper.updateComponentVariables(component,record,"Add");
            	helper.openContactModal(component);
            }
            else if(event.target.id == "editNode"){
                helper.updateComponentVariables(component,record,"Edit");
            	helper.openContactModal(component);
            }
        }
        else if (event.target.id == "deleteNode") {
            helper.openDeleteModal(component, event);
        }
        else if(event.target.getAttribute("class") == "recordLink"){
            //add logic to stop redirecting for newly created records
        	helper.redirectToSelectedContact(component, event);
		}
    },
    closeContactModal : function(component, event, helper){
        helper.closeContactModal(component);
    },
    modalSave : function(component, event, helper){
    	var selectedTabId = component.get("v.selectedTabId");
        if(selectedTabId == "existingContactTab"){
            component.set("v.errorMessage","");
            var isValidData = helper.validInfluenceMapData(component)
            if(isValidData){
                helper.onModalSave(component);
                helper.saveInfluenceMap(component, "Contact");
                helper.updateContactList(component);
            }
            else{
                $(".error.uiMessage").css("display","block");
            }
        }
        else if(selectedTabId == "newContactTab"){
            component.set("v.errorMessage", "");
            var isValidData = helper.validContactData(component);
            if(isValidData){
                //console.log("validData");
                helper.insertNewContact(component);
            }
            else{
                //console.log("Wrong Data");
            }
        }
    },
    goBack : function(component,event,helper){
    	helper.goBackToRecord(component);
    },
    saveMapData : function(component, event, helper){
        if(helper.dataSource && helper.dataSource.objInfluenceMap){
            var hierarchyData = helper.orgChart.getHierarchy();
            var jsonData = {};
            var parentId = "";
            helper.prepareFinalData(jsonData, hierarchyData, parentId);

            helper.finalSaveAction(component, jsonData);
        }
        else{
            //console.log("Empty JSON will be sent to the backend");
            helper.finalSaveAction(component, {});
        }

        //on data load, make <Id:Data> pair for each record
        //update those records on Edit action
        //add new <Id:Data> pair on Add action
        //on Save action, get Hierarchy using orgChart,
        //and make JSON by adding values from <Id, Data> pairs
    },
    addFirstNode : function(component, event, helper){
        //alert("Work in progress");
        var record = {};
        record.objInfluenceMap = record.objContact = {};
        record.objInfluenceMap.Id = "";
        helper.updateComponentVariables(component,record,"Add");
        helper.openContactModal(component);
        //helper.clearLookupField(component);
        //lookup now cleared from tab onactive function
    },
    closeDeleteModal : function(component, event, helper){
        helper.closeDeleteModal(component);
    },
    deleteContact : function(component, event, helper){
        helper.updateContactList(component, "Delete");
        helper.deleteNode(component, event);

    },
    selectedContactEvent : function(component, event, helper){
        component.set("v.nodeData.objContact", event.getParam("contact"));
        var contact = component.get("v.nodeData.objContact");
        component.set("v.nodeData.objInfluenceMap.Contact__c", contact.Id);
        //console.log("parentComponent-- selectedContactEvent fn, nodeData : ", component.get("v.nodeData"));
    },
    changeFilter : function(component,event, helper){
        helper.clearLookupField(component);
    },
    setLookupField : function(component, event, helper){
        //hide spinner
        component.set("v.modalSpinnerClass", "slds-hide");
        //helper.hideModalSpinner(component);
        var eventName = component.get("v.eventName");
        var contact = component.get("v.nodeData.objContact");
        //console.log("eventName : " + eventName + ", objCOntact : ", contact);
        if(eventName == "Add" && !contact){
            helper.clearLookupField(component);
        }
        else if(eventName == "Add" && contact){
            var lookupComponent = component.find("lookupComponent");
            //console.log("setting selectedCONtact, contact : ", contact);
        	lookupComponent.set("v.selectedContact", contact);
            //console.log("selectedContact : 138 : ", lookupComponent.get("v.selectedContact"));
        	lookupComponent.setContactFromParent(contact);
        }
    }
})