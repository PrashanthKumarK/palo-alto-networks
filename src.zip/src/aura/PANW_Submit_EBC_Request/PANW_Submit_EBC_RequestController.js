({
	doInit : function(component, event, helper) {
        try{
            var recId = component.get("v.recordId");
            var urlEvent = $A.get("e.force:navigateToURL");
            urlEvent.setParams({
                "url": "/apex/EBCRequest?OPPID="+recId
            });   
            urlEvent.fire(); 
        }catch(e){
            throw new AuraHandledException( 'Yor Error Message ==>'+e);   
        }
	}
})