({
    
    /* On the component Load this function call the apex class method, 
    * which is return the list of RecordTypes of object 
    * and set it to the lstOfRecordType attribute to display record Type values
    * on ui:inputSelect component. */
    
    fetchListOfRecordTypes: function(component, event, helper) {
        //get record Type Names
        var action = component.get("c.getRecordTypeNames");
        action.setParams({
            "sobjName": 'Resource_Request__c'
        });       
        action.setCallback(this, function(response) {
            component.set("v.lstOfRecordType", response.getReturnValue());
            component.set("v.isOpen", true);
        });
        $A.enqueueAction(action);
    },
    
    /* In this "createRecord" function, first we have call apex class method 
    * and pass the selected RecordType values[label] and this "getRecTypeId"
    * apex method return the selected recordType ID.
    * When RecordType ID comes, we have call  "e.force:createRecord"
    * event and pass object API Name and 
    * set the record type ID in recordTypeId parameter. and fire this event
    * if response state is not equal = "SUCCESS" then display message on various situations.
    */
    createRecord: function(component, event, helper) {
        component.set("v.isOpen", true);
        var action = component.get("c.getRecordTypeID");      
        var recordTypeLabel = component.find("recTypeSel").get("v.value");
        /*
        * Call to get the ID -May be we can use a diff emthod to avoid server call
        */
        action.setParams({
            "sObjName":'Resource_Request__c',
            "recordTypeLabel": recordTypeLabel
        });
        action.setCallback(this, function(response) {
            //Clear the window
            setTimeout(function(){
                $A.get("e.force:closeQuickAction").fire(); 
            }, 1000);          
            var state = response.getState();
            if (state === "SUCCESS") {
                var oppId = component.get("v.recordId");
		        var accId = component.get("v.oppRecord.AccountId");
                var createRecordEvent = $A.get("e.force:createRecord");
                var RecTypeID  = response.getReturnValue();
                createRecordEvent.setParams({
                    'entityApiName': 'Resource_Request__c',
                    'recordTypeId': RecTypeID,
                    'defaultFieldValues': {                    
						'Opportunity__c':oppId,
                        'Account__c':accId
                    }
                });
                createRecordEvent.fire();
                
            } else if (state == "ERROR") {
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Error!",
                    "message": "Please contact your administrator"
                });
                toastEvent.fire();
            }
        });
        $A.enqueueAction(action);
    },
    
    closeModal: function(component, event, helper) {
        $A.get("e.force:closeQuickAction").fire();
        // set "isOpen" attribute to false for hide/close model box 
        component.set("v.isOpen", false);
    },
    
    openModal: function(component, event, helper) {
        // set "isOpen" attribute to true to show model box
        component.set("v.isOpen", true);
    }   
})