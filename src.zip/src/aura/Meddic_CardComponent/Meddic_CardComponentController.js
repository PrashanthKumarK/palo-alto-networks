({
	selectCard : function(component, event, helper) {
            var cmpEvent = component.getEvent("selectCard");
			cmpEvent.setParams({
				"index" :  component.get('v.index')
			});
			cmpEvent.fire();
		
	}
})