({
	doInit: function(component, event, helper){
		helper.checkLockStatus(component, event, helper);
	}
});