({
    doInit : function(component, event, helper) {
        console.log('Function Entered Here---->');
        helper.getRecords(component);
        
    },
     getInput : function(cmp, event) { 
      alert("Please don’t forget to manually change the owner after you’ve reassigned the approver."); 
    }
})