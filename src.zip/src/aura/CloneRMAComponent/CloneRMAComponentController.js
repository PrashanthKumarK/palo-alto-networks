({
	doInit : function (component, event, helper) {
        try{
            var rId = component.get("v.recordId");
            var urlEvent = $A.get("e.force:navigateToURL");
            // set the url to be directed to  
            urlEvent.setParams({
                "url": "/apex/RMAClone?id="+rId+"&retURL="+rId
            });
            //fire the Event
            urlEvent.fire();
        }catch(e){
             throw new Error("Unexpected error occured! Try refreshing the page. If it continues to happen please contact your System Admin");
            console.error(e); 
        }
    }
})