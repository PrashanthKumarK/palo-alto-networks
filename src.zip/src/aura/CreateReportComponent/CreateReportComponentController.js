({
	doInit : function(component, event, helper) {
        try{
        //current Record ID
        var rId = component.get("v.recordId");
        var urlEvent = $A.get("e.force:navigateToURL");
        // set the url to be directed to
        urlEvent.setParams({
            "url": "/apex/EnterpriseRiskReport?accountid="+rId+"&retURL="+rId
        });
        //fire the event
        urlEvent.fire();
        }catch(e){
            throw new Error("Unexpected error occured! Try refreshing the page. If it continues to happen please contact your System Admin");
            console.error(e); 
        }
	}
})