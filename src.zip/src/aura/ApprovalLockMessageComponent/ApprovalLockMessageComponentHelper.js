({
	/* 
     * function name : checkLockStatus
     * description   : helper method to check if record is locked for editing
     */ 
	checkLockStatus: function(component, event, helper){
		// Record Id 
		var recId = component.get("v.recordId");
		// Controller Method
		var actionLockedCheck = component.get("c.checkRecordLockedStatus");
		// Pass the record id as parameter to check the locked status
		actionLockedCheck.setParams({
			"idSObject": recId
		});
		//  Handling the action callback
		actionLockedCheck.setCallback(this, function(response){
			var state = response.getState();
			// Check if the backend call is a success
			if (state === "SUCCESS") {
				var result = response.getReturnValue();
				console.log(result.lockStatus);
				// Check to see if the record is locked for editing
				if(result.lockStatus == true){
					component.set("v.displayMessage",true);
					// Displaying Approval Lock record message
					component.set("v.message",result.lockMessage);
				}
			}
		});
		// Call the backend action
		$A.enqueueAction(actionLockedCheck);
	}
 })