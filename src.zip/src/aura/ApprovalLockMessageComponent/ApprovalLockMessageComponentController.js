({
	/* 
     * function name : doInit
     * description   : controller method to check if record is locked for editing
     */ 
	doInit: function(component, event, helper){
		// Method call to check if the record is locked for editing due to approval process
		helper.checkLockStatus(component, event, helper);
	}
});