({
    doInit : function(component, event, helper) {
        try{
        var recId = component.get("v.recordId");
        // method getClaimRecordId from ReimbursmentClaimController
        var action = component.get("c.getClaimRecordId");
        // set param to method
        action.setParams({
            "recordId": component.get("v.recordId")
        });
        
        // Register the callback function
       action.setCallback(this, function(response) {
            var status = response.getState();
            var data = response.getReturnValue();
            var urlEvent = $A.get("e.force:navigateToURL");
            if(data!=null){
            	if(data.id)
                alert('There is already a Claim against this MDF. Please edit the existing Claim.');     
                urlEvent.setParams({
                    "url": "/"+recId
                });   
                urlEvent.fire();
            }else if(data==null){
                // set the url to be directed to
            	urlEvent.setParams({
                    "url": "/apex/Claim_Redirect?frid="+recId
                });   
                urlEvent.fire();    
            } 
            
        });
        // enqueue the Action
        $A.enqueueAction(action);	
        }catch(e){
           throw new Error("Unexpected error occured! Try refreshing the page. If it continues to happen please contact your System Admin");
            console.error(e);    
        }
    }
})