({
	doInit : function(component, event, helper) {
        console.log("function enter here");
        // get record Id
		var recId = component.get("v.recordId");
        // calling serverside method
        var action = component.get("c.checkExport");
        // setting action parameters
		component.set("v.displayMessage",false);
        action.setParams({
            OppId : recId
        });
        action.setCallback(this, function(a){
            console.log("function enter here");
            console.log("a.getReturnValue()"+a.getReturnValue());
            if (a.getState() === "SUCCESS"){
                
                if(a.getReturnValue() == "true"){
                    //close quick action modal
                    $A.get("e.force:closeQuickAction").fire() 
                    // Redirecting to ExpATRRecords Page if return value true.else showing error message.
                    window.open('/apex/ExpATRRecords?oppId='+recId,'_self');
                }else{
                    // save alert message
					component.set("v.displayMessage",true);
                    component.set("v.alertMessage",'Not CPQ renewals');
                    var modal = component.find("modalMessage");
                    $A.util.removeClass(modal,'slds-hide');
                    $A.util.addClass(modal,'slds-show');
                }
            } 
        });
		$A.enqueueAction(action);
	},
    closeModal : function(component, event, helper){
        $A.get("e.force:closeQuickAction").fire() ;
    }
})