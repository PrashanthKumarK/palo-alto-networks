({
	Initialfunction : function(component) {
		// get record Id
		var recId = component.get("v.recordId");
        // calling serverside method
        var action = component.get("c.getStatus");
        // setting action parameters
        action.setParams({
            OppId : recId
        });
        action.setCallback(this, function(a){
            if (a.getState() === "SUCCESS"){
                $A.get("e.force:closeQuickAction").fire() 
                if(a.getReturnValue() == "true"){
                    // Redirecting to ExpATRRecords Page if return value true.else showing error message.
                    window.open('/apex/ExpATRRecords?oppId='+recId,'_self');
                }else{
                    // showing alert message
                    window.alert('Not CPQ renewals');
                }
            } 
        });
	}
})