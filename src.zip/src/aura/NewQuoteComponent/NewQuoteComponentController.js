({
    doInit : function(component, event, helper) {
        // Get a reference to the getWeather() function defined in the Apex controller
		var action = component.get("c.getAccountRecord");
        var recId = component.get("v.recordId");
       
        action.setParams({
            "accountId": component.get("v.recordId")
        });
        // Register the callback function
        action.setCallback(this, function(response) {
            var status = response.getState();
            var data = response.getReturnValue();
            var recId = data.Id;
            var urlEvent = $A.get("e.force:navigateToURL");
            
            urlEvent.setParams({
                "url": "/"+recId
            });   
            urlEvent.fire();
         
        });
        // Invoke the service
        $A.enqueueAction(action);
    }
    
})