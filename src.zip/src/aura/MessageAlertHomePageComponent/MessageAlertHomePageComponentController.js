({
	navigate : function(component, event, helper) {
         	
        var urlEvent = $A.get("e.force:navigateToURL");
		urlEvent.setParams({
		  "url": 'https://stage.paloaltonetworks.com/content/campaigns/salestools/lp/index.html'
		});
		urlEvent.fire();
    },

    navigateNda : function(component, event, helper) {
         	
        var urlEvent = $A.get("e.force:navigateToURL");
		urlEvent.setParams({
		  "url": 'https://paloaltonetworks.tap.thinksmart.com/prod/Portal/ShowWorkFlow/ShowWorkflowDetail/dfd213e1-95d9-4c6d-ad42-92232d7ff856'
		});
		urlEvent.fire();
    }
})