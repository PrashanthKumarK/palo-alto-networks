({
	closeModalHelp : function() {
		$A.get("e.force:closeQuickAction").fire();
	},
    submitHelp : function(component, event, helper)
       {
       var spinner = component.find("submitSpinner");
       $A.util.toggleClass(spinner, "slds-hide");
       var recId = component.get("v.recordId");
       
       component.set("v.displayMessage",false);
       var comments = component.get("v.commentsValue");
       var action = component.get("c.submitForApproval");
       action.setParams({
            "recordId": recId,
             "comments":comments
        });
        
       action.setCallback(this, function(response) {
            var status = response.getState();
            var resultData = response.getReturnValue();
           	if(resultData == 'Success'){
                component.set("v.severityValue","confirm");
               	component.set("v.messageValue", 'The record has been submitted successfully for Approval' );
            }else{
                component.set("v.severityValue","error");
                var finalMessage = "The following error/errors have occured: "+resultData;
                component.set("v.messageValue",finalMessage );
            }
            component.set("v.displayForm",false);
            component.set("v.displayMessage",true);
           	$A.util.toggleClass(spinner, "slds-hide");
                  
    	});
        
        $A.enqueueAction(action);
        
	}

    
})