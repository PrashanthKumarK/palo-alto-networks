({
	doInit : function(component, event, helper) {
		var spinner = component.find("submitSpinner");
        component.set("v.displayForm",false);
        component.set("v.displayMessage",false);
		$A.util.toggleClass(spinner, "slds-hide");
        //Current Record ID
		var recId = component.get("v.recordId");
        //method submitForApprovalValidation from PromotionSubmitApprovalController
        var action = component.get("c.submitForApprovalValidation");
        // set param to method 
        action.setParams({
            "recordId": component.get("v.recordId"),
        });
        
         // Register the callback function
         action.setCallback(this, function(response) {
            var status = response.getState();
            var resultData = response.getReturnValue();
            if (resultData === false) {
                             
                component.set("v.severityValue","error");
                component.set("v.messageValue", "You need to Upload an Attachment to this Promotion to be able to Submit it for Approval since the Promotion belongs to a Government Account.");
            	  component.set("v.displayForm",false);
                component.set("v.displayMessage",true);
            }else{
               component.set("v.displayForm",true);
               component.set("v.displayMessage",false);
            }
         
        });
        // enqueue the Action
        $A.enqueueAction(action);
	},
    closeModal : function(component, event, helper) {
       helper.closeModalHelp(component, event, helper);
    },
	
	submit : function(component, event, helper) {
       helper.submitHelp(component, event, helper);
	}

})