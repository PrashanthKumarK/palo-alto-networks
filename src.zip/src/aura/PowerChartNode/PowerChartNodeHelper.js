({
	  openSuggestions : function(component,event,helper,dataSource) {
        var autocomplete = event.target;
        var autocomplete_result = component.find('suggestion').getElement();//  event.target.nextSibling;
         
        //if(!autocomplete.value) {
            this.popupClearAndHide(component,event,helper,autocomplete_result);
           // return;
       // } 
        var a = new RegExp("^" + autocomplete.value, "i");
        for(var x = 0, b = document.createDocumentFragment(), c = false; x < dataSource.length; x++) {
            if(a.test(dataSource[x].name)) {
                c = true;
                var d = document.createElement("p");
                d.innerText = dataSource[x].name;
                d.setAttribute("data-id",dataSource[x].id  );
                b.appendChild(d);
            }
        }
        if(c == true) {
            autocomplete_result.innerHTML = "";
            autocomplete_result.style.display = "block";
            autocomplete_result.appendChild(b);
            return;
        }
        //this.popupClearAndHide(component, event, helper, autocomplete_result);
     },
     popupClearAndHide : function(component, event, helper, autocomplete_result){
         autocomplete_result.innerHTML = "";
         autocomplete_result.style.display = "none";
    },
    selectItem : function(component,event,helper,dataSource) { 
          var input = component.find('input').getElement(); 
          var inputEmail = component.find('inputEmail').getElement(); 
          for(var i=0;i<dataSource.length;i++){
              if(dataSource[i].id == event.target.dataset.id){
                  input.value = dataSource[i].name
                  inputEmail.value = dataSource[i].email
              }
          }
          component.find('suggestion').getElement().innerHtml = "";
          component.find('suggestion').getElement().style.display = "none";
    } 
})