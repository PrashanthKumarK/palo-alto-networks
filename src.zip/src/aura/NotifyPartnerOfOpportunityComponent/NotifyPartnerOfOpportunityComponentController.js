({
    /*
     * function name : doInit
     * return value  : none
     * description   : fetches Reseller Email value for current opportunity on component load
     */
	doInit : function(component, event, helper) {
		helper.getResellerEmail(component);
	},
    /*
     * function name : updateOpportunity
     * return value  : none
     * description   : updates EmailPartner checkbox to TRUE, which triggers Workflow which in turn send an email to the partner
     */
    updateOpportunityData : function(component, event, helper){
        helper.updateOpportunityData(component);
    },
    /*
     * function name : backToRecord
     * return value  : none
     * description   : refreshes the Opportunity record detail page, closes component
     */
    backToRecord : function(component, event, helper){
        helper.redirectBack(component);
    },
    /*
     * function name : closeComponent
     * return value  : none
     * description   : closes component, no update of detail page required
     */
    closeComponent : function(component, event, helper){
        helper.closeComponent(component);
    }
})