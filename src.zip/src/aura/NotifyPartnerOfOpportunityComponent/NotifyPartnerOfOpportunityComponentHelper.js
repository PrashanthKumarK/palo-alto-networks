({
    /*
     * function name : getResellerEmail
     * parameters    : none (except component variables)
     * return value  : none, sets component variable values inside function
     * description   : get relevant fields from Apex for current Opportunity
     */
	getResellerEmail : function(component) {
        
        var action = component.get("c.checkResellerEmail");
        // , component.get("v.recordId")
        action.setParams({
            recordId : component.get("v.recordId")
        });
        action.setCallback(this, function(response){
            //hide spinner
            component.set("v.spinnerClass", "slds-hide");
            
            if(response.getState() === "SUCCESS"){
                var responseData = response.getReturnValue();
                if(responseData.isSuccess === true){
                    //show Confirm button
                    component.set("v.resellerEmailFound", true);
                }
                else{
                    //show failure message
                    $A.util.addClass(component.find("messageDiv"), "redText");
                }
                component.set("v.message", responseData.message);
            }
            else{
                //show failure message and set generic error
                $A.util.addClass(component.find("messageDiv"), "redText");
                component.set("v.message", "Function call failed. Please retry or contact administrator");
            }
        });
        $A.enqueueAction(action);
	},
    /*
     * function name : updateOpportunityData
     * parameters    : none
     * return value  : none
     * description   : updates current Opportunity (logic in apex)
     */
    updateOpportunityData : function(component){
        //show spinner
        component.set("v.spinnerClass", "");
        //hide Confirm button
        component.set("v.resellerEmailFound", false);
        
        //call apex function to update Opportunity record
        var action = component.get("c.updateOpportunity");
        action.setParams({
            recordId : component.get("v.recordId")
        });
        action.setCallback(this, function(response){
            //hide spinner
            component.set("v.spinnerClass", "slds-hide");
            
            if(response.getState() === "SUCCESS"){
                var responseData = response.getReturnValue();
                if(responseData.isSuccess === true){
                    this.showToastMessage(component, "success", responseData.message);
                    this.closeComponent(component);
                }
                else{
                    //show failure message
                    $A.util.addClass(component.find("messageDiv"), "redText");
                }
                component.set("v.message", responseData.message);
            }
            else{
                //show failure message
                $A.util.addClass(component.find("messageDiv"), "redText");
                component.set("v.message", "Function call failed. Please retry or contact administrator");
            }
        });
        $A.enqueueAction(action);
    },
    /*
     * function name : closeComponent
     * parameters    : none
     * return value  : none
     * description   : refreshes the Opportunity record detail page, closes component
     */
    closeComponent : function(component){
    	$A.get("e.force:closeQuickAction").fire();  
    },
    /*
     * function name : showToastMessage
     * parameters    : toastType -> success/error/info/warning, toastMessage -> message to be displayed
     * return value  : none
     * description   : displays message in the event of success/failure of an action involving apex call
     */
    showToastMessage : function(component, toastType, toastMessage){
        var showToastEvent = $A.get("e.force:showToast");
        showToastEvent.setParams({
            type: toastType,
            message: toastMessage,
            mode: "dismissible"
        });
        showToastEvent.fire();
	}
})