({
    myAction : function(component, event, helper) {
        helper.renderChart(component, event, helper);
        helper.renderCompensationCategoryChart(component, event, helper);
    },
    
})