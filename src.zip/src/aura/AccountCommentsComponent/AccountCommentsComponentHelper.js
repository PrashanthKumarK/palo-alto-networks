({
toggleClass: function(component,componentId,className) {
    var modal = component.find(componentId);
    $A.util.removeClass(modal,className+'hide');
    $A.util.addClass(modal,className+'open');
},

toggleClassInverse: function(component,componentId,className) {
    var modal = component.find(componentId);
    $A.util.addClass(modal,className+'hide');
    $A.util.removeClass(modal,className+'open');
    },
saveRecordHelp : function(component, event, helper) {
        var newMessage = component.get("v.objAcc.Comments__c");
        var action = component.get("c.getSaveComment");
          action.setParams({
            "newMsg": component.get("v.objAcc.Comments__c"),
            "RecordId": component.get("v.recordId")  
        });
        // Register the callback function
        action.setCallback(this, function(response) {
            var status = response.getState();
            if(status == 'SUCCESS'){
                var toast = $A.get("e.force:showToast");
                if(newMessage){
                    if (toast){
                        //fire the toast event in Salesforce1 and Lightning Experience
                        toast.setParams({
                            "title": "Success!",
                            "message": "Comment saved succesfully"  
                        });
                        toast.fire();
                    } 
                }else{
                	if (toast){
                        //fire the toast event in Salesforce1 and Lightning Experience
                        toast.setParams({
                            "title": "WARNING!!",
                            "message": "Comment Not Added. Please Add Comment!!!!"  
                        });
                        toast.fire();
                    }        
                }
                    
                component.set("v.displayInput",false);
				component.set("v.displayOutput",true);
				helper.toggleClassInverse(component,'backdrop','slds-backdrop--');
				helper.toggleClassInverse(component,'modaldialog','slds-fade-in-');
            }
        });
        // enqueue the Action
        $A.enqueueAction(action);
    },
renderInputHelp: function(component, event, helper){
		
		var styles = ".forceStyle .viewport .oneHeader {z-index:0; }";
		
		
		helper.toggleClass(component,'backdrop','slds-backdrop--');
		helper.toggleClass(component,'modaldialog','slds-fade-in-');
    },
hidePopupHelp: function(component, event, helper){
		//Toggle CSS styles for hiding Modal
		helper.toggleClassInverse(component,'backdrop','slds-backdrop--');
		helper.toggleClassInverse(component,'modaldialog','slds-fade-in-');
		
	}
 })