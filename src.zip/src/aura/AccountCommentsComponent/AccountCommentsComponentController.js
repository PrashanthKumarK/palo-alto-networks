({
    doInit : function(component, event, helper) {
        //Current Account ID
    	var recId = component.get("v.recordId");
        //method getComments from AccountCommentsController
        var action = component.get("c.getComments");
        
        helper.toggleClassInverse(component,'backdrop','slds-backdrop--');
		helper.toggleClassInverse(component,'modaldialog','slds-fade-in-');
		
        component.set("v.displayInput",false);
        component.set("v.displayOutput",true);
        // set param to method  
        action.setParams({
            "RecordId": component.get("v.recordId")
        });
        // Register the callback function
        action.setCallback(this, function(response) {
            var status = response.getState();
            var data = response.getReturnValue();
            var comment = component.get("v.objAcc.Comments__c");
            
            component.set("v.objAcc.Comments__c",data);
            
        });
        // enqueue the Action
        $A.enqueueAction(action);
    },
    
    saveRecord : function(component, event, helper) {
        helper.saveRecordHelp(component, event, helper);
        $A.get('e.force:refreshView').fire();
    },
    renderInput: function(component, event, helper){
		helper.renderInputHelp(component, event, helper);
    },
	hidePopup:function(component, event, helper){
		helper.hidePopupHelp(component, event, helper);
	}
})