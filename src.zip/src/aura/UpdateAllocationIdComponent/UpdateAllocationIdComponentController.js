({
	doInit : function (component, event, helper) {
        try{
        var rId = component.get("v.recordId");
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": "/apex/MDFUpdAllocadia?id="+rId+"&retURL="+rId
        });
        urlEvent.fire();
        }catch(e){
            throw new Error("Unexpected error occured! Try refreshing the page. If it continues to happen please contact your System Admin");
            console.error(e);    
        }
    }
})