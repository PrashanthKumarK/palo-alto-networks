({
	navigate : function(component, event, helper) {
         	
        console.log('Enter the area');
        var urlEvent = $A.get("e.force:navigateToURL");
		urlEvent.setParams({
		  "url": 'https://www.paloaltonetworks.com/partners/partner-portal.html'
		});
		urlEvent.fire();
    }
})