({
	doInit:function(component,event,helper){
		//get the record Id
		var recId=component.get("v.recordId");
		// Set default value to show message
		component.set("v.displayMessage", false);
        console.log('recordId : ' + recId);
		var urlEvent=$A.get("e.force:navigateToURL");
		//method getCanEditServiceEngagement from ServiceEngagementWebservice
		var action=component.get("c.getCanEditServiceEngagement");
		action.setParams({
			"seId":component.get("v.recordId")
		});
		//Register the callback function
		action.setCallback(this,function(response){
			var state = response.getState();
			if (state === "SUCCESS") {
				var data = response.getReturnValue();
				console.log('data'+data);
				var canEdit = false;
				var status = "";
				var serviceId = data.Service_Engagement__c;
				if (data && data.length){
					var result = JSON.parse(data);
					canEdit = result.canEdit;
					status = result.status;
				}
				if (canEdit){
					//set the URL to be directed to
					var editRecordEvent = $A.get("e.force:editRecord");
	  				editRecordEvent.setParams({
	        			"recordId": recId
					});
	   		    	editRecordEvent.fire();
				}else if(status === "Pending Approval"){
					component.set("v.displayMessage", true);
					component.set("v.message", "This Service Engagement is in Pending Approval status.\n\nPlease contact the administrator to approve.");
				}else{
					component.set("v.displayMessage", true);
					component.set("v.message", "This Service Engagement is not in an editable status.\n\nPlease contact the administrator to help.");
				}
			}
		});
		// Action Call
		$A.enqueueAction(action); 
	}
})