({
	doInit: function(component, event, helper){
        
		var recId = component.get("v.recordId");
		var action = component.get("c.getJsonWrapper");
		helper.toggleClassInverse(component,'backdrop','slds-backdrop--');
		helper.toggleClassInverse(component,'modaldialog','slds-fade-in-');
		component.set("v.displaymessage", false);
		
        component.set("v.displayInput",false);
        component.set("v.displayOutput",true);
		action.setParams({
			"idRecord": recId,
		});
		
		
		action.setCallback(this, function(response){
			var state = response.getState();
			if (state === "SUCCESS") {
				console.log(response.getReturnValue());
                var data = response.getReturnValue();
                console.log('check data---->',data);
                var dataWrapper = data.listFieldWrapper;
                // set the edit button display boolean value based on the dataWrapper
                // if dataWrapper is null means there were no fields to edit.
                if(dataWrapper != null && dataWrapper.length>0){
                    component.set("v.displayEdit",true);
                }else{
                    component.set("v.displayEdit",false);
                }
				component.set("v.objAccount", data.objAccount);
				component.set("v.wrapperData",dataWrapper);
				
			}
		});
        
        
		$A.enqueueAction(action);
	},
	saveAcc: function(component, event, helper){
        var dataWrapper = component.get("v.wrapperData");
		var accInfo = component.get("v.objAccount");
		component.set("v.displaymessage", false);
		var recId = component.get("v.recordId");
		var action = component.get("c.saveAccount");
		//var actionFetch = component.get("c.getAccountRecord");
		action.setParams({
			"accRecord": component.get("v.objAccount"),
            "idOfLookUp": dataWrapper[3].fieldValue,
		});
        /*actionFetch.setParams({
			"idRecord": recId,
		});*/
		action.setCallback(this, function(response){
			var state = response.getState();
			var resultResponse = response.getReturnValue();
			if (response.getState() == "SUCCESS") {
                console.log('check status');
				component.set("v.displayInput",false);
				component.set("v.displayOutput",true);
				helper.toggleClassInverse(component,'backdrop','slds-backdrop--');
				helper.toggleClassInverse(component,'modaldialog','slds-fade-in-');
			}else{
				component.set("v.Message", response.getReturnValue());
				component.set("v.displaymessage", true);
			
			}
		});
		/*actionFetch.setCallback(this, function(response){
			var state = response.getState();
			if (state === "SUCCESS") {
				component.set("v.objAccount", response.getReturnValue());
				helper.toggleClassInverse(component,'backdrop','slds-backdrop--');
				helper.toggleClassInverse(component,'modaldialog','slds-fade-in-');
			}
		});*/
		$A.enqueueAction(action);
		//$A.enqueueAction(actionFetch);
	},
    renderInput: function(component, event, helper){
		
		helper.toggleClass(component,'backdrop','slds-backdrop--');
		helper.toggleClass(component,'modaldialog','slds-fade-in-');
    },
	hidePopup:function(component, event, helper){
		//Toggle CSS styles for hiding Modal
		helper.toggleClassInverse(component,'backdrop','slds-backdrop--');
		helper.toggleClassInverse(component,'modaldialog','slds-fade-in-');
	},
    getupdateValue : function(component,event,helper){
        var selecteduserGetFromEvent = event.getParam("recordByEvent");
        var selectedlabel = event.getParam("labelofLookup");
        var wrapperlist = component.get("v.wrapperData");
        if (selecteduserGetFromEvent != null && selecteduserGetFromEvent !== undefined) {
        	var IdofRecrd = selecteduserGetFromEvent['Id'];
            console.log('id---->',IdofRecrd);
            wrapperlist[3].fieldValue = IdofRecrd;
            component.set("v.wrapperData",wrapperlist);
        }
    },
});