({
	doInit : function(component, event, helper) {
        try{
        // Id of the current Lead Record      
        var recId = component.get("v.recordId");
        var action = component.get("c.getDealLeadRecord");
        // set param to method  
        action.setParams({
            "recordId": component.get("v.recordId")
        });
                
        // Register the callback function
        action.setCallback(this, function(response) {
            var status = response.getState();
            var data = response.getReturnValue();
            var urlEvent = $A.get("e.force:navigateToURL");
            if(data.status == 'Deal Registration - Rejected'){
            	alert('This lead is associated with a rejected deal registration and can no longer be converted.');    
            	// set the url to be directed to
                urlEvent.setParams({
                    "url": "/"+recId
                });   
                urlEvent.fire();  
            }else{
                if(data.status == '' || data.status ==null){
                	// set the url to be directed to
                    urlEvent.setParams({
                        "url": "/apex/DealReg?leadid="+recId+"&retURL="+recId
                    });   
                    urlEvent.fire();    
                }else{
                	alert('This lead has been converted into deal registration and cannot be converted again.');    
                    // set the url to be directed to
                    urlEvent.setParams({
                        "url": "/"+recId
                    });   
                    urlEvent.fire();                    
                } 
            }
            
        });
        // enqueue the Action  
        $A.enqueueAction(action);
        }catch(e){
             throw new Error("Unexpected error occured! Try refreshing the page. If it continues to happen please contact your System Admin");
            console.error(e); 
        }
	}
})