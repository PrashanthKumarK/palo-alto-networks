({
	doInit: function(component, event, helper){
		var recId = component.get("v.recordId");
				
		helper.toggleClassInverse(component,'backdrop','slds-backdrop--');
		helper.toggleClassInverse(component,'modaldialog','slds-fade-in-');
		
        component.set("v.displayInput",false);
        component.set("v.displayOutput",true);
        
		helper.setOrderIssuePicklist(component, event, helper);
		helper.setOrderIssueValue(component, event, helper);
  		helper.editEDI(component, event, helper);
	},
    
    //Save Opportunity after editing EDI fields
	saveOpp: function(component, event, helper){
        helper.saveOppRec(component, event, helper);
	},
    
    renderInput: function(component, event, helper){
		
		var styles = ".forceStyle .viewport .oneHeader {z-index:0; }";
		component.set("v.cssStyle", styles);
		
		helper.toggleClass(component,'backdrop','slds-backdrop--');
		helper.toggleClass(component,'modaldialog','slds-fade-in-');
    },
    
	hidePopup:function(component, event, helper){
		//Toggle CSS styles for hiding Modal
		helper.toggleClassInverse(component,'backdrop','slds-backdrop--');
		helper.toggleClassInverse(component,'modaldialog','slds-fade-in-');
		component.set("v.cssStyle", "");
	}
});