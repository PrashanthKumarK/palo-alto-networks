({
    close: function(component, event, helper) {
        helper.closeHelper(component, event, helper);
    },
    AddingNode: function(component, event, helper) {
        component.set("v.show", false);
    },
    keyPressController : function(component, event, helper) {
        helper.keyPressHelper(component, event, helper);
    },
    hideSpinner : function (component, event, helper) {
        helper.hideSpinnerHelper(component, event, helper);
    },
    showSpinner : function (component, event, helper) {
        helper.showSpinnerHelper(component, event, helper);
    },
    handleComponentEvent : function(component, event, helper) {
        helper.handleComponentEventHelper(component, event, helper);
    },
    clear : function(component,event,helper){
        helper.clearHelper(component, event, helper);
    },
})