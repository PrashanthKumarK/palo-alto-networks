({
	 searchHelper : function(component,event,getInputkeyWord) {
        var action = component.get("c.fetchContact");
        var opportunityId = component.get("v.recordId");
        action.setParams({
            'searchKeyWord': getInputkeyWord,
            'opportunityId' : opportunityId
        });
        
        action.setCallback(this, function(response) {
            if (response.getState() === "SUCCESS") {
                var storeResponse = response.getReturnValue();
                
                if (storeResponse == null ) {
                    component.set("v.Message", 'No Result Found...');
                } else if(storeResponse.length > 0 && storeResponse != null) {
                    component.set("v.Message", 'Search Result...');
                }
                component.set("v.listOfSearchRecords", storeResponse);
                
                alert(storeResponse);
            }
        });
        $A.enqueueAction(action);
    },
    
    adjustPill : function(component,event,helper) {
        var forclose = component.find("lookup-pill");
        $A.util.addClass(forclose, 'slds-show');
        $A.util.removeClass(forclose, 'slds-hide');
        
        var forclose = component.find("searchRes");
        $A.util.addClass(forclose, 'slds-is-close');
        $A.util.removeClass(forclose, 'slds-is-open');
        
        var lookUpTarget = component.find("lookupField");
        $A.util.addClass(lookUpTarget, 'slds-hide');
        $A.util.removeClass(lookUpTarget, 'slds-show');  
    },
   
    closeHelper: function(component, event, helper) {
        component.set("v.SearchKeyWord",'');
        component.set("v.show", false);
    },
    keyPressHelper : function(component, event, helper) {
        // get the search Input keyword   
        var getInputkeyWord = component.get("v.SearchKeyWord");
        
        if( getInputkeyWord.length > 0 ){
            var forOpen = component.find("searchRes");
            $A.util.addClass(forOpen, 'slds-is-open');
            $A.util.removeClass(forOpen, 'slds-is-close');
            this.searchHelper(component,event,getInputkeyWord);
        }
        else{  
            component.set("v.listOfSearchRecords", null ); 
            var forclose = component.find("searchRes");
            $A.util.addClass(forclose, 'slds-is-close');
            $A.util.removeClass(forclose, 'slds-is-open');
        }
        
    },
    
    // automatically call when the component is done waiting for a response to a server request.  
    hideSpinnerHelper : function (component, event, helper) {
        var spinner = component.find('spinner');
        if(spinner != undefined)
        {
            var evt = spinner.get("e.toggle");
            evt.setParams({ isVisible : false });
            evt.fire();  
        }
    },
    
   // automatically call when the component is waiting for a response to a server request.
    showSpinnerHelper : function (component, event, helper) {
        var spinner = component.find('spinner');
        if(spinner != undefined)
        {
            var evt = spinner.get("e.toggle");
            evt.setParams({ isVisible : true });
            evt.fire();    
        }
    },
    
     // This function call when the end User Select any record from the result list.   
    handleComponentEventHelper : function(component, event, helper) {
        
        // get the selected Account record from the COMPONETN event 	 
        var selectedAccountGetFromEvent = event.getParam("accountByEvent");
        
        component.set("v.selectedRecord" , selectedAccountGetFromEvent); 
        
        this.adjustPill(component, event, helper);
        
    },
    
    // function for clear the Record Selaction 
    clearHelper :function(component,event,helper){
        
        var pillTarget = component.find("lookup-pill");
        var lookUpTarget = component.find("lookupField"); 
        
        $A.util.addClass(pillTarget, 'slds-hide');
        $A.util.removeClass(pillTarget, 'slds-show');
        
        $A.util.addClass(lookUpTarget, 'slds-show');
        $A.util.removeClass(lookUpTarget, 'slds-hide');
        
        component.set("v.SearchKeyWord",null);
        component.set("v.listOfSearchRecords", null );
    },
})