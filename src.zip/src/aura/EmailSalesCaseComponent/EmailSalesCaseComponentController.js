({
	doInit : function(component, event, helper) {
        try{
            //Current Case ID
            var recId = component.get("v.recordId");
            //method getCaseRecord from CaseEmailController
            var action = component.get("c.getCaseRecord");
            // set param to method 
            action.setParams({
                "caseId": component.get("v.recordId")
            });
                    
            // Register the callback function
            action.setCallback(this, function(response) {
                var status = response.getState();
                var urlEvent = $A.get("e.force:navigateToURL");
                if (status === 'SUCCESS'){
                    // set the url to be directed to
                    urlEvent.setParams({
                        "url": "/"+recId
                    });   
                    urlEvent.fire();
                    }
                
            });
            // enqueue the Action
            $A.enqueueAction(action);
        }catch(e){
           throw new Error("Unexpected error occured! Try refreshing the page. If it continues to happen please contact your System Admin");
            console.error(e); 
        }
	}
})