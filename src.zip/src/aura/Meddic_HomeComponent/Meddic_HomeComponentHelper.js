({
	fetchTitle : function(component, event, helper) {
 
 		var action = component.get("c.fetchTitleDetails");
         action.setParams({               
                "parentId" : component.get('v.recordId')
            });
            action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var title = response.getReturnValue();
                component.set('v.titleDetails', response.getReturnValue());
                var titleDetails = component.get('v.titleDetails'); 
                console.log('titleDetails');
                console.log(titleDetails);
                
                 if(component.get("v.resetDisplayVal"))
                 {
                  	 var displyArray = [];
                     var titledetails = component.get('v.titleDetails');
                     for(var i=0;i< titledetails.length;i++){
                         
                         if(component.get('v.selectedtitle').title == titledetails[i].Title__c ){
                             displyArray.push(titledetails[i]);
                         }
                     }
                    console.log(displyArray);
                    component.set("v.displyArray", displyArray);   
                    component.set("v.resetDisplayVal", false);
                 }
                
            }
            else if (state === "ERROR") {
                alert('Error : ' + JSON.stringify(errors));
            }
        });
        $A.enqueueAction(action);      

      

    },
    setTitle : function(component, event, helper) {
          var titles = [{title:"Current Situation and Key Drivers"},{title:"Business Problem"},{title:"Decision Making Factor"},{title:"Customer Pain"},{title:"Business Pains"},{title:"Compelling Event"},{title:"Risk to Deal"},{title:"Next Steps"}];
        component.set('v.title',titles);
        component.set('v.selectedtitle',titles[0]);
    }
})