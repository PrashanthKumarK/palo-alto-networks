({
	doInit : function(component, event, helper) {
        component.set("v.resetDisplayVal",true);
        helper.fetchTitle(component, event, helper);
        helper.setTitle(component, event, helper); 
        
    },
    selectCard:function(component, event, helper) { 
        component.set('v.expandAll',false);
        component.set('v.expandallCheck',false);
       
        console.log(event.target); 
         var selectedIndex = event.getParam('index'); 
      
       // var selectedIndex = event.target.dataset.index || event.target.parentElement.dataset.index;
        
        var title =  component.get('v.title');
        component.set('v.selectedtitle',title[selectedIndex]); 
        var titledetails = component.get('v.titleDetails');
        console.log(titledetails);
        
        var displyArray = [];
        
        for(var i=0;i< titledetails.length;i++){
            
            if(title[selectedIndex].title == titledetails[i].Title__c ){
                displyArray.push(titledetails[i]);
            }
        }
        console.log(displyArray);
        component.set("v.displyArray", displyArray);
        
    },
    onChange:function(component, event, helper){
         component.set('v.expandallCheck',true);
         component.set('v.expandAll',!component.get('v.expandAll'));
        
},
    newRecord:function(component, event, helper){
       console.log(event.target); 
       var selectedValue = event.target.dataset.valueid || event.target.parentElement.dataset.valueid;
       component.set('v.detailClickedName',selectedValue);
        component.set('v.recorddetailsid','');  
         component.set('v.description','');
         component.set('v.stakeholerId','');
       component.set('v.editrecord',false);        
        component.set('v.show',true);        
},
    editRecord:function(component, event, helper){
       var item = event.getParam('item'); 
        console.log(item);
       component.set('v.detailClickedName',item.Title__c);
       component.set('v.recorddetailsid',item.Id);
        component.set('v.description',item.Notes__c);  
        component.set('v.stakeholerId',item.Stakeholder__c);
        component.set('v.editrecord',true);
        component.set('v.show',true);
        
},
    refresh : function(component, event, helper){
        component.set("v.resetDisplayVal",true);
     	helper.fetchTitle(component, event, helper);   
    }
    

})