({
    doInit: function(component, event, helper) {
        //show spinner
        $A.util.toggleClass(component.find("componentSpinner"),"slds-hide");
        //location.reload();
        
    },
    afterScript : function(component, event, helper){
    	/*Indicates that the initial rendering of the root application has completed. */
        //hide spinner
        $A.util.toggleClass(component.find("componentSpinner"),"slds-hide");
        if (!component.get("v.isScriptLoaded")) {
            component.set("v.isScriptLoaded", true);
            
            var dataSource = {
                id: "abcd",
                parentId: "zxcv",
                name: "Amber McKenzie",
                title: "CEO",
                phone: "678-772-470",
                buyingRole: "Decision Maker",
                status: "Champion",
                focus: "Economic/Strategic",
                contactLevel: "High",
                mail: "lemmons@jourrapide.com",
                address: "Atlanta, GA 30303",
                children:[
                    {
                        id: "abcd7",
                		parentId: "zxcv7",
                        name: "John Miller",
                        title: "EMEA Head",
                        buyingRole: "Approver",
                        status: "Mobilizer",
                        focus: "Economic/Strategic",
                		contactLevel: "Low",
                        phone: "837-912-4971",
                        mail: "jhon@acme.com",
                        address: "Atlanta, GA 30303"
                    },
                    {
                        id: "abcd8",
                		parentId: "zxcv8",
                        name: "Kylie Jenner",
                        title: "APAC Head",
                        buyingRole: "Decision Maker",
                        status: "Neutral",
                        focus: "Operational",
                		contactLevel: "Low",
                        phone: "777-912-4971",
                        mail: "kylie.jenner@acme.com",
                        address: "Atlanta, GA 30303"
                    },
                    {
                        id: "abcd9",
                		parentId: "zxcv9",
                        name: "Mike Highworth",
                        title: "Technical Manager",
                        buyingRole: "Evaluator",
                        status: "Champion",
                        focus: "Technical",
                		contactLevel: "High",
                        phone: "937-912-4988",
                        mail: "m.highworth@jourrapide.com",
                        address: "Atlanta, GA 30303"
                    },
                    {
                        id: "abcd10",
                		parentId: "zxcv10",
                        name: "Ana Mourinho",
                        title: "IOT Advocate",
                        buyingRole: "Approver",
                        status: "Blocker",
                        focus: "Technical",
                		contactLevel: "Medium",
                        phone: "937-912-5571",
                        mail: "ana.mourinho@jourrapide.com",
                        address: "Atlanta, GA 30303"
                    },
                    {
                        id: "abcd1",
                		parentId: "zxcv1",
                        name: "Ava Field",
                        title: "COO",
                        buyingRole: "Approver",
                        status: "Mobilizer",
                        focus: "Economic/Strategic",
                		contactLevel: "Low",
                        phone: "937-912-4971",
                        mail: "anderson@jourrapide.com",
                        address: "Atlanta, GA 30303",
                        children: [
                            {
                                id: "abcd2",
                				parentId: "zxcv2",
                                name: "Rebecca Randall",
                                title: "Optometrist",
                                buyingRole: "Evaluator",
                                status: "Neutral",
                                focus: "Operational",
                                contactLevel: "Medium",
                                phone: "801-920-9842",
                                mail: "JasonWGoodman@armyspy.com",
                                address: "Atlanta, GA 30303"
                            },
                            {
                                id: "abcd3",
                				parentId: "zxcv3",
                                name: "Spencer May",
                                title: "System operator",
                                buyingRole: "Evaluator",
                                status: "Blocker",
                                focus: "Technical",
                                contactLevel: "High",
                                phone: "Conservation scientist",
                                mail: "hodges@teleworm.us",
                                address: "Atlanta, GA 30303"
                            }
                        ]
                    },
                    {
                        id: "abcd4",
                		parentId: "zxcv4",
                        name: "Evie Johnson",
                        title: "CFO",
                        buyingRole: "Approver",
                        status: "Neutral",
                        focus: "Operational",
                        contactLevel: "Medium",
                        phone: "314-722-6164",
                        mail: "thornton@armyspy.com",
                        address: "Atlanta, GA 30303",
                        children: [
                            {
                                id: "abcd5",
                				parentId: "zxcv5",
                                name: "Max Ford",
                                title: "Budget manager",
                                buyingRole: "Evaluator",
                                status: "Champion",
                                focus: "Technical",
                                contactLevel: "Low",
                                phone: "989-474-8325",
                                mail: "hunter@teleworm.us",
                                address: "Atlanta, GA 30303"
                            },
                            {
                                id: "abcd6",
                				parentId: "zxcv6",
                                name: "Riley Bray",
                                title: "Structural metal fabricator",
                                buyingRole: "Evaluator",
                                status: "Neutral",
                                focus: "Technical",
                                contactLevel: "Medium",
                                phone: "479-359-2159",
                                address: "Atlanta, GA 30303"
                            }
                        ]
                    }
                ]
            };

            /*Setting 1 second delayed time to let the static resources load completely. */
            var element;
            setTimeout(function() {
                //make legendDiv visible
                //$A.util.addClass(component.find("legendDiv"), "showLegendDiv");
                element = $(component.find('chart-Container').getElement());
                helper.orgChart = element.orgchart({
                    'data': dataSource,
                    'draggable': true,
                    'pan': true,
                    'zoom' : true,
                    'createNode': function($node, data) {
                        //setting a unique id to every node.
                        $node[0].id = (new Date().getTime()) * 1000 + Math.floor(Math.random() * 1001);

                		//injecting the required HTML.
                        $node[0].innerHTML =
                        '<div aura:id="node" class="undefined slds-box" style="text-align: center;border-radius: 4px 4px 4px 4px";background:#ebeef3;>'+
                            '<div style="text-align: center;background:#ebeef3;">'+
                                '<p class="emptyDiv"></p>'+
                                '<h4>'+data.name+'</h4>'+
                                '<h5>'+data.title+'</h5>'+
                            '<div class="slds-grid" style="background-color:#fff;color:#000;margin-top:10px;">'+
                                    '<div class="slds-size--4-of-12" style="border-right:1px solid #eee;margin-right:2px;">'+
                                        '<div aria-class="'+ (data.buyingRole ? data.buyingRole : '') +'" class="" style="font-size: initial;"><div class="tooltip">'+
                                            (data.buyingRole ? data.buyingRole.charAt(0) : '')+
                                        '<span class="tooltiptext">'+(data.buyingRole ? data.buyingRole: '') +'</span></div></div>'+
                                    '</div>'+
                                    '<div class="slds-size--4-of-12" style="border-right:1px solid #eee;margin-right:2px;">'+
                                    	'<div aria-class="'+ (data.status ? data.status: '') +'" class="" style="font-size: initial;" ><div class="tooltip">'+
                                        	(data.status ? data.status.charAt(0): '')+
                            			'<span class="tooltiptext">'+(data.status ? data.status: '')+'</span></div></div>'+
                                    '</div>'+
                                    '<div class="slds-size--4-of-12">'+
                                    	'<div aria-class="'+ (data.focus ? data.focus : '') +'" class="" style="font-size: initial;"><div class="tooltip">'+
                                        	(data.focus ? data.focus.charAt(0) : '')+
                                    	'<span class="tooltiptext">'+(data.focus ? data.focus: '')+'</span></div></div>'+
                                    '</div>'+
                            '<div class="extraInfo" style="display:none;"><span>'+ (data.phone?data.phone:'')+'</span><span>'+(data.mail?data.mail:'')+'</span></div>'+
                                '</div>'+
                            '<div class="slds-grid slds-p-top--xx-small"><div class="slds-progress-bar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="100" role="progressbar"> <span aria-class="'+ (data.contactLevel ? data.contactLevel : '') +'" class="slds-progress-bar__value" style="width:'+ helper.contactLevelWidth[helper.contactLevels.indexOf(data.contactLevel)]+';background:'+ helper.contactLevelColors[helper.contactLevels.indexOf(data.contactLevel)] +'"> <span class="slds-assistive-text tooltiptext">Level of Contact: Low</span> </span></div></div>'+
                            '<div>'+
                            '<div>'+
                                '<i id="editNode" class="fa fa-pencil fa-fw" style="position:absolute; top:0px; right: 0px;" aria-hidden="true"></i>&nbsp;'+
                                '<i id="deleteNode" class="fa fa-trash fa-fw" style="position:absolute; top:0px; left: 0px;" aria-hidden="true"></i>'+
                                '<i id="addNode" class="fa fa-plus fa-fw"  aria-hidden="true"></i>&nbsp;'+
                            '</div>'+
                        '</div>';

                    }
                })
            }, 100);
            
        }

    },
     /*This function will catch the event on the basis of button click- Add/Delete and execute the Action. */
    action: function(component, event, helper) {
		//following block of code need cleanup (05-Dec-2017)
		//console.log('--action orgChart Json : ', helper.orgChart);
		//helper.overrideHeaderStyle(component, event, helper);
		component.set("v.isViewClicked", false);

        if (event.target.id == 'viewNode') {
            helper.eventName = 'view';
            component.set("v.modalHeader","View Contact Info");
            var node = $(event.target.parentElement.parentElement.parentElement);
            console.log('--viewNode : ', node);
            //Make modal read only
            component.set("v.isViewClicked", true);
            /*
        	component.set("v.contactName",node[0].childNodes[0].innerText);
            component.set("v.contactTitle",node[0].childNodes[1].innerText);
            component.set("v.contactBuyingRole",node[0].childNodes[3].childNodes[0].innerText);
            component.set("v.contactStatus",node[0].childNodes[3].childNodes[1].innerText);
            component.set("v.contactFocus",node[0].childNodes[3].childNodes[2].innerText);
            */
            //component.set("v.openContactModal", true);
        }
        else if(event.target.id == 'editNode'){
            //override header styling
            component.set("v.cssStyle", ".forceStyle .viewport.oneHeader.desktop {z-index:0} .forceStyle.desktop .viewport{overflow:hidden}");

            helper.eventName = 'edit';
            component.set("v.modalHeader","Edit Contact Info");
            //save event's context in a variable for future use
            helper.clickEvent = event;
            var node = $(event.target.parentElement.parentElement.parentElement);

            console.log('--editNode : ', node);
            //these values have  to be changed if DIV structure (in init method) is changed
            var contactName = node[0].childNodes[1].innerText;
            var contactTitle = node[0].childNodes[2].innerText;
            var contactBuyingRole = node[0].childNodes[3].childNodes[0].childNodes[0].attributes[0].value;
            var contactStatus = node[0].childNodes[3].childNodes[1].childNodes[0].attributes[0].value;
            var contactFocus = node[0].childNodes[3].childNodes[2].childNodes[0].attributes[0].value;
            var contactPhone = node[0].childNodes[3].childNodes[3].childNodes[0].innerText;
            var contactEmail = node[0].childNodes[3].childNodes[3].childNodes[1].innerText;
            var contactLevel = node[0].childNodes[4].childNodes[0].childNodes[1].attributes[0].textContent;
            component.set("v.contactName", contactName);
            component.set("v.contactTitle", contactTitle);
            component.set("v.contactBuyingRole", contactBuyingRole);
            component.set("v.contactStatus", contactStatus);
            component.set("v.contactFocus", contactFocus);
            component.set("v.contactPhone", contactPhone);
            component.set("v.contactEmail", contactEmail);
            component.set("v.contactLevel", contactLevel);
            //open Modal
            component.set("v.openContactModal", true);
        }
        else if (event.target.id == 'addNode') {
            //override header styling
            component.set("v.cssStyle", ".forceStyle .viewport.oneHeader.desktop {z-index:0} .forceStyle.desktop .viewport{overflow:hidden}");

            helper.eventName = 'add';
            component.set("v.modalHeader","Add Contact Info");
            //save event's context in a variable for future use
            helper.clickEvent = event;
            //reset input fields values
            component.set("v.contactName","");
            component.set("v.contactTitle","");
            component.set("v.contactBuyingRole","");
            component.set("v.contactStatus","");
            component.set("v.contactFocus","");
            component.set("v.contactPhone","");
			component.set("v.contactEmail","");
            component.set("v.contactLevel","");
            //open modal
            component.set("v.openContactModal", true);
        }
        else if (event.target.id == 'deleteNode') {
            helper.eventName = 'delete';
            if(window.confirm('Are you sure ?') ){
                var oc = helper.orgChart;
                var $node = $(event.target.parentElement);

                //if user is trying to delete the top level node.
                if ($node[0] === $('.orgchart').find('.node:first')[0]) {
                    if (!window.confirm('you are going to delete the whole chart!!!')) {
                        return;
                    }
                }
                oc.removeNodes($node);
                $(event.target.parentElement).val('').data('node', '');
             }
        }
     },
    closeContactModal : function(component, event, helper){
        component.set("v.openContactModal", false);
    },
    addNewContact : function(component, event, helper){
        var oc = helper.orgChart;
        if(!helper.clickEvent){
            console.log('Empty Event data');
            return;
        }
        if(helper.eventName == 'add'){
            //to reach div.node (the top node)
            var $node = $(helper.clickEvent.target.parentElement.parentElement.parentElement.parentElement.parentElement);
            console.log('--add node : ', $node);
            var data = {
                'children': [{
                    'name': component.get("v.contactName"),
                    'title': component.get("v.contactTitle"),
                    'buyingRole': component.get("v.contactBuyingRole"),
                    'status': component.get("v.contactStatus"),
                    'focus': component.get("v.contactFocus"),
                    'phone': component.get("v.contactPhone"),
                    'mail': component.get("v.contactEmail"),
                    'contactLevel': component.get("v.contactLevel"),
                    'address': 'Atlanta, GA 30303',
                    'relationship': '110'
                }]
            }
            //Check if the focussed node already has a child or not.
            var hasChild = $node.parent().attr('colspan') > 0 ? true : false;
            //if not, Add a chid Node else add a sibling to the already present child Node(s).
            if (!hasChild) {
                oc.addChildren($node, data);
            }
            else {
                console.log('--closest sibling : ', $node.closest('tr').siblings('.nodes').find('.node:first'));
                oc.addSiblings($node.closest('tr').siblings('.nodes').find('.node:first'), {
                    'siblings': [{
                        'name': component.get("v.contactName"),
                        'title': component.get("v.contactTitle"),
                        'buyingRole': component.get("v.contactBuyingRole"),
                        'status': component.get("v.contactStatus"),
                        'focus': component.get("v.contactFocus"),
                        'phone': component.get("v.contactPhone"),
                        'mail': component.get("v.contactEmail"),
                        'contactLevel': component.get("v.contactLevel"),
                        'address': 'Atlanta, GA 30303',
                        'relationship': '110',
                        'Id': '12333'
                    }]
                })
            }
        }
        if(helper.eventName == 'edit'){
            var $node = $(helper.clickEvent.target.parentElement.parentElement.parentElement);
            console.log('- ~edit : ', $node);
            var contactName = component.get("v.contactName");
            var contactTitle = component.get("v.contactTitle");
            var contactBuyingRole = component.get("v.contactBuyingRole");
            var contactStatus = component.get("v.contactStatus");
            var contactFocus = component.get("v.contactFocus");
            var contactPhone = component.get("v.contactPhone");
            var contactEmail = component.get("v.contactEmail");
            var contactLevel = component.get("v.contactLevel");
            $node[0].childNodes[1].innerText = contactName;
            $node[0].childNodes[2].innerText = contactTitle;
            //have to update buyingRole, Status, Focus values at three different places and change background color as well
            //changing aria-class value (used to populate modal picklists)
            $node[0].childNodes[3].childNodes[0].childNodes[0].attributes[0].value = contactBuyingRole;
            $node[0].childNodes[3].childNodes[1].childNodes[0].attributes[0].value = contactStatus;
            $node[0].childNodes[3].childNodes[2].childNodes[0].attributes[0].value = contactFocus;

            //changing tooltip values
            $node[0].childNodes[3].childNodes[0].childNodes[0].childNodes[0].childNodes[1].textContent = contactBuyingRole;
            $node[0].childNodes[3].childNodes[1].childNodes[0].childNodes[0].childNodes[1].textContent = contactStatus;
            $node[0].childNodes[3].childNodes[2].childNodes[0].childNodes[0].childNodes[1].textContent = contactFocus;
            //changing one alphabet
            $node[0].childNodes[3].childNodes[0].childNodes[0].childNodes[0].childNodes[0].textContent = contactBuyingRole.charAt(0);
            $node[0].childNodes[3].childNodes[1].childNodes[0].childNodes[0].childNodes[0].textContent = contactStatus.charAt(0);
            $node[0].childNodes[3].childNodes[2].childNodes[0].childNodes[0].childNodes[0].textContent = contactFocus.charAt(0);

            /*
            $node[0].childNodes[3].childNodes[0].childNodes[0].innerHTML = contactBuyingRole.charAt(0)+'<span class="tooltiptext">'+ contactBuyingRole +'</span>';
            $node[0].childNodes[3].childNodes[1].childNodes[0].innerHTML = contactStatus.charAt(0)+'<span class="tooltiptext">'+ contactStatus +'</span>';
            $node[0].childNodes[3].childNodes[2].childNodes[0].innerHTML = contactFocus.charAt(0)+'<span class="tooltiptext">'+ contactFocus +'</span>';
            */
            ////changing background-color
            var buyingRoleStyle = $node[0].childNodes[3].childNodes[0].childNodes[0].attributes[2].value;
            var statusStyle = $node[0].childNodes[3].childNodes[1].childNodes[0].attributes[2].value;
            var focusStyle = $node[0].childNodes[3].childNodes[2].childNodes[0].attributes[2].value;
            
            //removing old color code and adding new color code in style attribute (background property should be last)
            /* no longer required (11-Dec-2017)
            $node[0].childNodes[3].childNodes[0].childNodes[0].attributes[2].value = buyingRoleStyle.substr(0,buyingRoleStyle.indexOf('#')) + helper.colorsBuyingRole[helper.colorsBuyingRoleValues.indexOf(contactBuyingRole)];
            $node[0].childNodes[3].childNodes[1].childNodes[0].attributes[2].value = statusStyle.substr(0,buyingRoleStyle.indexOf('#')) + helper.colorsStatus[helper.colorsStatusValues.indexOf(contactStatus)];
            $node[0].childNodes[3].childNodes[2].childNodes[0].attributes[2].value = focusStyle.substr(0,focusStyle.indexOf('#')) + helper.colorsFocus[helper.colorsFocusValues.indexOf(contactFocus)];
			*/
            $node[0].childNodes[3].childNodes[3].childNodes[0].innerText = contactPhone;
            $node[0].childNodes[3].childNodes[3].childNodes[1].innerText = contactEmail;
            
            //saving contacLevel value in aria-class attribute for re-reference, changing color & width of progress bar
            $node[0].childNodes[4].childNodes[0].childNodes[1].attributes[0].textContent = contactLevel;
            $node[0].childNodes[4].childNodes[0].childNodes[1].attributes[2].textContent = 'width:'+helper.contactLevelWidth[helper.contactLevels.indexOf(contactLevel)]+';background:'+ helper.contactLevelColors[helper.contactLevels.indexOf(contactLevel)];
        }
        component.set("v.openContactModal", false);
        
    },
    overrideHeaderStyle : function(component, event, helper){
        component.set("v.cssStyle", ".forceStyle .viewport.oneHeader.desktop {z-index:0} .forceStyle.desktop .viewport{overflow:hidden}");
    },
    zoomOutMap : function(component, event, helper){
        //alert('reached here, width: ' , component.find("chart-Container").get("v.style"));       
        /*
        helper.chartWidth += 5;
        helper.chartMarginLeft -= 1/helper.chartWidth;
        $('.chart-Container').css('width',helper.chartWidth+'%');
        $('.chart-Container').css('margin-left',helper.chartMarginLeft+'%');
        */
        //helper.chartZoom -= helper.chartZoom*0.1;
        //$('.chart-Container').css('zoom',helper.chartZoom);
    },
    zoomInMap : function(component, event, helper){
        /*
        helper.chartWidth -= 5;
        helper.chartMarginLeft += 1/helper.chartWidth;
        $('.chart-Container').css('width',helper.chartWidth+'%');
        $('.chart-Container').css('margin-left',helper.chartMarginLeft+'%');
        */
        //helper.chartZoom += helper.chartZoom*0.1;
        //$('.chart-Container').css('zoom',helper.chartZoom);
    }
})