({
    doInit : function(component, event, helper) {
        try{
            // Get a reference to the getWeather() function defined in the Apex controller
            var action = component.get("c.getAccountRecord");
            var recId = component.get("v.recordId");
            var baseUrl = component.get("c.getInstanceBaseURL");
            var InstanceUrl ;
            baseUrl.setCallback(this, function(response) {
                InstanceUrl = response.getReturnValue();    
            })
            
            action.setParams({
                "accountId": component.get("v.recordId")
            });
            // Register the callback function
            action.setCallback(this, function(response) {
                var status = response.getState();
                var data = response.getReturnValue();
                var recId = data.Id;
                var urlEvent = $A.get("e.force:navigateToURL");
                if(data.EnableNOWOnboardingTaskView__c == false){
                    //$A.get('e.force:refreshView').fire();
                    if (status === 'SUCCESS'){
                        var dismissActionPanel = $A.get("e.force:closeQuickAction"); 
                        dismissActionPanel.fire();
                    }
                    alert("Onboarding tasks have not been shared with this Partner. Please click the Push Onboarding Tasks button before attempting to view tasks.");    
    
                }else{
                    if (status === 'SUCCESS'){
                    urlEvent.setParams({
                        "url": InstanceUrl+"/apex/VNOWNonDistiView?accountId="+recId
                    });   
                    urlEvent.fire();
                    }
                }
            });
            // Invoke the service
            $A.enqueueAction(baseUrl);
            $A.enqueueAction(action);
        }catch(e){
           throw new Error("Unexpected error occured! Try refreshing the page. If it continues to happen please contact your System Admin");
            console.error(e);    
        }
    }
    
})