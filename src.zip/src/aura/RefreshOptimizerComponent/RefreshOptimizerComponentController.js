({
	toggleSection : function(component, event, helper) {
		// make article names dynamic
		var scenario = event.currentTarget.name;
		var element = document.getElementById('article_' + scenario);
		if (element != null)
			element.classList.toggle('slds-is-open');
	},
    init : function (component, event, helper) {
        var action = component.get("c.initializeComponent");
        var recordId = component.get("v.recordId");
        helper.showSldsSpinner(component, "refreshSpinner");
        //var opportunityId = '0063D000007Jkhz';
        action.setParams({
            opportunityId: recordId
        });

		//TODO: Error handling and Exception Handling        
        action.setCallback(this,function(result){
        	if (result.getState() == 'SUCCESS') {
	        	var scenarioWrapper = result.getReturnValue();
	            component.set("v.scenarioWrapper", scenarioWrapper);
	            var products = [];
	            for (var key in scenarioWrapper.existingProducts) {
	                products.push({label:key, value:key});
	            }
	            component.set("v.products", products);
	            var scenarios = scenarioWrapper.scenarios;
	            if (typeof scenarios !== 'undefined' && scenarios.length > 0) {
	                component.set("v.scenarios", scenarios);
	            } else {
	                helper.generateDefaultScenarios(component);
                    
	            }
                helper.generateComparisonData(component);
                helper.updateCumulativeScenario(component);
	            scenarios = component.get("v.scenarios");
	            window.setTimeout(function() {
		    		for (var scenario in scenarios) {
		    			helper.createBarChart(component, scenario, scenarios[scenario].Product_Family__c, 
		           		scenarios[scenario].Refresh_Product_Family__c, scenarioWrapper.productDataSheet);
		    		}
                    helper.createCumulativeChart(component);
                    helper.hideSldsSpinner(component, "refreshSpinner");
				}, 100);
	        }
        });
        $A.enqueueAction(action);
    },
    saveScenariosToDatabase: function (component, event, helper) {
        helper.saveScenariosToDatabase(component, event, false);
    },
    updateCalculationsOnScenarioChange : function(component, event, helper) {
     	var index = event.getSource().get('v.labelClass');
    	helper.updateOnScenarioChange (component, event, index);
	},
    updateCalculationsOnModelChange : function(component, event, helper) {
        var index = event.getSource().get('v.name');
    	helper.updateOnScenarioChange (component, event, index);
	},
	addNewScenario : function(component, event, helper) {
		helper.openDialog(component.find('modalNewScenario'), 'slds-fade-in-');
		helper.openDialog(component.find('backdrop'), 'slds-backdrop_');
	},
    removeScenario : function(component, event, helper) {
		helper.removeScenario(component, event);
	},
	/*displayToolTip : function(component, event, helper) {
		helper.toggleToolTip(component, event);
	},
	hideToolTip : function(component, event, helper) {
		helper.toggleToolTip(component, event);
	},*/
	closeNewScenario : function(component, event, helper) {
		helper.closeDialog(component.find('backdrop'), 'slds-backdrop_');
		helper.closeDialog(component.find('modalNewScenario'), 'slds-fade-in-');
	},
    addNewScenario : function(component, event, helper) {
		var newScenario = helper.generateDefaultScenario(component, null);
		component.set("v.newScenario", newScenario);
		helper.openDialog(component.find('modalNewScenario'), 'slds-fade-in-');
		helper.openDialog(component.find('backdrop'), 'slds-backdrop_');
	},
    createNewScenario : function(component, event, helper) {
		var scenarios = component.get("v.scenarios");
		var scenarioWrapper = component.get("v.scenarioWrapper");
		var newScenario = component.get("v.newScenario");
        helper.generateComparisonDataForScenario(component, newScenario);
		scenarios.push(newScenario);
		component.set("v.scenarios", scenarios);
        helper.updateCumulativeScenario(component);
		window.setTimeout(function() {
	         		helper.createBarChart(component, scenarios.length-1, scenarios[scenarios.length-1].Product_Family__c, 
		           		scenarios[scenarios.length-1].Refresh_Product_Family__c, scenarioWrapper.productDataSheet);
            		helper.updateCumulativeChart(component);
				}, 100);
		helper.closeDialog(component.find('backdrop'), 'slds-backdrop_');
		helper.closeDialog(component.find('modalNewScenario'), 'slds-fade-in-');
		//add scroll into new component
	},
	newScenarioProductChanged : function(component, event, helper) {
		var newScenario = component.get("v.newScenario");
		newScenario.Refresh_Product_Family__c = component.get("v.scenarioWrapper").productDataSheet[newScenario.Product_Family__c].Refresh_Product_Family__c;
		component.set("v.newScenario", newScenario);
	},
    toggleCumulativePanel : function(component, event, helper) {
        component.set('v.isCumulativePanelOpen', !component.get('v.isCumulativePanelOpen'));
        var relatedOpties = component.get('v.relatedOpportunities');
        //console.log(relatedOpties);
        if (relatedOpties == null || relatedOpties.length == 0) {
            helper.getRelatedOpportunities(component, event);
        }
    },
    toggleIncludeScenario : function(component, event, helper) {
       	var dataIndex = parseInt(event.currentTarget.name);
        var scenarios = component.get("v.scenarios");
        scenarios[dataIndex].Include_In_Cumulative_Calculation__c = event.currentTarget.checked;
        component.set("v.scenarios", scenarios);
        helper.updateCumulativeScenario(component);
        helper.updateCumulativeChart(component);
    },
    createNewOpportunity : function(component, event, helper) {
    	helper.createNewOpportunity(component, event);
    },
    toggleInfoDisplay : function(component, event, helper) {
    	helper.toggleHelper(component, event);
	},
	generatePdf : function(component, event, helper) {
		helper.generatePdf(component, helper);
	}
})