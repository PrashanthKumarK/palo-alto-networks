({
	doInit : function(component, event, helper) {
        helper.initialize(component, event);
	}
})