({
	initialize : function(component, event) {
		var action = component.get("c.getUsersAssociatedWithTerritory");
        var accountId = component.get("v.recordId");
        action.setParams({
            objectId: accountId
        });
        
        action.setCallback(this,function(result){
            component.set("v.dataList", result.getReturnValue());
        });
        $A.enqueueAction(action);
	}
})