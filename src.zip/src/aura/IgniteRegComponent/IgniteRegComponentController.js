({
	doInit: function(component, event, helper) {
        //call apex class method
        
        var action = component.get('c.getwrapperdata');
        action.setCallback(this,function(response){
            //store state of respons
            var state = response.getState();
            if (state === "SUCCESS") {
                //set response value(map) in myMap attribute on component.
                
                
                
                
                component.set('v.SalesPathDataWrapper',response.getReturnValue());
                component.set('v.RegionAndWebDataWrapper',response.getReturnValue().DataWrapperList);
                component.set('v.SalesRepWrapper',response.getReturnValue().SalesRepSummaryByOpp);
                component.set('v.SalesRepRegion',response.getReturnValue().SalesRepRegion);
                component.set('v.SalesRepName',response.getReturnValue().SalesRepName);
                component.set('v.reportURL',response.getReturnValue().reportURL);
                component.set('v.IgniteSalesRepLoggedIn',response.getReturnValue().IgniteSalesRepLoggedIn);
                
                if(response.getReturnValue().IgniteSalesRepLoggedIn){
                    component.set('v.displaymsg',false);
                }else{
                    component.set('v.displaymsg',true);
                }
                
                var custs = [];
                var conts = response.getReturnValue().SalesRepSummaryByOpp;
                for ( key in conts ) {
                    custs.push(key);
                }
                component.set("v.keyList", custs);
                
                
                
                
            }
        });
        $A.enqueueAction(action);
    },
})