({
    doInit : function (component, event, helper) {
        var rId = component.get("v.recordId");
        console.log('rId------>'+rId);
        var urlEvent = $A.get("e.force:navigateToURL");
        urlEvent.setParams({
            "url": "/apex/EBCRequest?ACTID="+rId
        });
        urlEvent.fire();
    }
})